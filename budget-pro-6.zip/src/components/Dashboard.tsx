import React, { useState } from "react";
import { Account, Transaction, DashboardBlock, UserPreferences } from "../types";
import { ArrowUp, ArrowDown, Wallet, TrendingUp, TrendingDown, PiggyBank, Eye, EyeOff } from "lucide-react";

interface DashboardProps {
  accounts: Account[];
  transactions: Transaction[];
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
  onNavigate: (screen: string) => void;
}

export default function Dashboard({
  accounts,
  transactions,
  preferences,
  onUpdatePreferences,
  onNavigate,
}: DashboardProps) {
  const [period, setPeriod] = useState<"all" | "month" | "year">("all");
  const [hoveredPieIndex, setHoveredPieIndex] = useState<number | null>(null);

  // Helper to format values respecting Incognito mode
  const fmt = (val: number) => {
    if (preferences.incognito) {
      return "••• €";
    }
    return `${val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
  };

  const getFilteredTransactions = () => {
    const now = new Date();
    return transactions.filter((tx) => {
      const txDate = new Date(tx.date);
      if (period === "month") {
        return (
          txDate.getFullYear() === now.getFullYear() &&
          txDate.getMonth() === now.getMonth()
        );
      }
      if (period === "year") {
        return txDate.getFullYear() === now.getFullYear();
      }
      return true;
    });
  };

  const filteredTxs = getFilteredTransactions();

  // Metrics calculation
  const totalIncome = filteredTxs
    .filter((tx) => tx.type === "Revenu")
    .reduce((sum, tx) => sum + tx.amount, 0);

  const totalExpense = filteredTxs
    .filter((tx) => tx.type === "Depense")
    .reduce((sum, tx) => sum + tx.amount, 0);

  const balance = totalIncome - totalExpense;

  const totalWealth = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  // Reorder sections handler
  const moveBlock = (index: number, direction: "up" | "down") => {
    const order = [...preferences.dashboardOrder];
    const targetIdx = direction === "up" ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= order.length) return;

    // Swap elements
    const temp = order[index];
    order[index] = order[targetIdx];
    order[targetIdx] = temp;

    onUpdatePreferences({ dashboardOrder: order });
  };

  // SVG Cashflow Chart calculation (Last 6 Months logic)
  const renderCashflowChart = () => {
    const monthLabels = ["Janv", "Févr", "Mars", "Avril", "Mai", "Juin", "Juil", "Août", "Sept", "Oct", "Nov", "Déc"];
    const now = new Date();
    const monthsData: { label: string; income: number; expense: number }[] = [];

    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const m = d.getMonth();
      const y = d.getFullYear();

      const mIncome = transactions
        .filter((t) => {
          const td = new Date(t.date);
          return td.getMonth() === m && td.getFullYear() === y && t.type === "Revenu";
        })
        .reduce((sum, t) => sum + t.amount, 0);

      const mExpense = transactions
        .filter((t) => {
          const td = new Date(t.date);
          return td.getMonth() === m && td.getFullYear() === y && t.type === "Depense";
        })
        .reduce((sum, t) => sum + t.amount, 0);

      monthsData.push({
        label: `${monthLabels[m]} ${String(y).slice(-2)}`,
        income: mIncome,
        expense: mExpense,
      });
    }

    const maxAmount = Math.max(
      ...monthsData.map((d) => Math.max(d.income, d.expense)),
      100 // Avoid division by zero
    );

    const width = 600;
    const height = 180;
    const padding = 30;

    return (
      <div className="w-full">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
          {/* Y Axis Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((r, i) => {
            const y = padding + (height - padding * 2) * (1 - r);
            return (
              <g key={i}>
                <line
                  x1={padding}
                  y1={y}
                  x2={width - padding}
                  y2={y}
                  stroke="rgba(255, 255, 255, 0.05)"
                  strokeDasharray="4 4"
                />
                {!preferences.incognito && (
                  <text
                    x={padding - 5}
                    y={y + 4}
                    fill="#8888a8"
                    fontSize="9px"
                    textAnchor="end"
                    className="font-mono"
                  >
                    {Math.round(maxAmount * r)}€
                  </text>
                )}
              </g>
            );
          })}

          {/* Lines */}
          {monthsData.map((d, idx) => {
            const segmentWidth = (width - padding * 2) / (monthsData.length - 1);
            const x = padding + idx * segmentWidth;
            const yIncome = padding + (height - padding * 2) * (1 - d.income / maxAmount);
            const yExpense = padding + (height - padding * 2) * (1 - d.expense / maxAmount);

            return (
              <g key={idx}>
                {/* Vertical helper line on hover */}
                <line
                  x1={x}
                  y1={padding}
                  x2={x}
                  y2={height - padding}
                  stroke="rgba(255,255,255,0.02)"
                  strokeWidth="10"
                  className="hover:stroke-[rgba(255,255,255,0.08)] cursor-pointer transition-all"
                />

                {/* X labels */}
                <text
                  x={x}
                  y={height - padding + 15}
                  fill="#8888a8"
                  fontSize="10px"
                  textAnchor="middle"
                >
                  {d.label}
                </text>

                {/* Data point indicators */}
                <circle cx={x} cy={yIncome} r="4" fill="#4ade80" className="hover:scale-125 transition-transform" />
                <circle cx={x} cy={yExpense} r="4" fill="#f87171" className="hover:scale-125 transition-transform" />
              </g>
            );
          })}

          {/* Polyline Paths */}
          {(() => {
            const segmentWidth = (width - padding * 2) / (monthsData.length - 1);
            const incomePoints = monthsData
              .map((d, idx) => `${padding + idx * segmentWidth},${padding + (height - padding * 2) * (1 - d.income / maxAmount)}`)
              .join(" ");
            const expensePoints = monthsData
              .map((d, idx) => `${padding + idx * segmentWidth},${padding + (height - padding * 2) * (1 - d.expense / maxAmount)}`)
              .join(" ");

            return (
              <>
                <polyline
                  fill="none"
                  stroke="#4ade80"
                  strokeWidth="3"
                  points={incomePoints}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <polyline
                  fill="none"
                  stroke="#f87171"
                  strokeWidth="3"
                  points={expensePoints}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </>
            );
          })()}
        </svg>
      </div>
    );
  };

  // Pie Chart calculations for double visualization (Category vs Bank)
  const getExpensesByCategory = () => {
    const map: { [key: string]: number } = {};
    let total = 0;
    filteredTxs
      .filter((tx) => tx.type === "Depense")
      .forEach((tx) => {
        map[tx.category] = (map[tx.category] || 0) + tx.amount;
        total += tx.amount;
      });
    return {
      total,
      data: Object.entries(map)
        .map(([label, value]) => ({ label, value }))
        .sort((a, b) => b.value - a.value),
    };
  };

  const getExpensesByAccount = () => {
    const map: { [key: string]: number } = {};
    let total = 0;
    filteredTxs
      .filter((tx) => tx.type === "Depense")
      .forEach((tx) => {
        const acc = accounts.find((a) => a.id === tx.accountId);
        const name = acc ? acc.name : "Compte Inconnu";
        map[name] = (map[name] || 0) + tx.amount;
        total += tx.amount;
      });
    return {
      total,
      data: Object.entries(map)
        .map(([label, value]) => ({ label, value }))
        .sort((a, b) => b.value - a.value),
    };
  };

  const renderPieChart = (title: string, queryFn: () => { total: number; data: { label: string; value: number }[] }) => {
    const { total, data } = queryFn();
    const colors = [
      "#4ade80", // lime
      "#60a5fa", // blue
      "#f87171", // red
      "#f59e0b", // amber
      "#a78bfa", // purple
      "#2dd4bf", // teal
      "#fb7185", // rose
      "#e879f9", // fuchsia
    ];

    if (total === 0) {
      return (
        <div className="bg-zinc-900 border border-zinc-800/60 rounded-xl p-5 flex flex-col items-center justify-center h-full min-h-[220px]">
          <p className="text-zinc-500 text-xs italic">{title}</p>
          <span className="text-zinc-600 text-xs mt-2">Aucune dépense enregistrée</span>
        </div>
      );
    }

    // Pie chart geometry variables
    const size = 180;
    const cx = size / 2;
    const cy = size / 2;
    const r = 60;
    const innerR = 40;

    let accumulatedAngle = -Math.PI / 2;

    return (
      <div className="bg-zinc-900 border border-zinc-800/60 rounded-xl p-5 flex flex-col justify-between h-full min-h-[220px]">
        <div className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-4">
          {title}
        </div>
        <div className="flex items-center gap-6">
          <div className="relative w-[120px] h-[120px] flex-shrink-0 select-none">
            <svg viewBox={`0 0 ${size} ${size}`} className="w-full h-full transform -rotate-90">
              {data.map((item, idx) => {
                const percentage = item.value / total;
                const angle = percentage * Math.PI * 2;
                const endAngle = accumulatedAngle + angle;

                // Path points for donut chart sector
                const x1 = cx + r * Math.cos(accumulatedAngle);
                const y1 = cy + r * Math.sin(accumulatedAngle);
                const x2 = cx + r * Math.cos(endAngle);
                const y2 = cy + r * Math.sin(endAngle);

                const ix1 = cx + innerR * Math.cos(accumulatedAngle);
                const iy1 = cy + innerR * Math.sin(accumulatedAngle);
                const ix2 = cx + innerR * Math.cos(endAngle);
                const iy2 = cy + innerR * Math.sin(endAngle);

                const largeArcFlag = angle > Math.PI ? 1 : 0;

                // Build modern absolute SVG donut path string
                const dPath = `
                  M ${x1} ${y1}
                  A ${r} ${r} 0 ${largeArcFlag} 1 ${x2} ${y2}
                  L ${ix2} ${iy2}
                  A ${innerR} ${innerR} 0 ${largeArcFlag} 0 ${ix1} ${iy1}
                  Z
                `;

                accumulatedAngle = endAngle;
                const color = colors[idx % colors.length];

                return (
                  <path
                    key={idx}
                    d={dPath}
                    fill={color}
                    className="transition-all duration-200 cursor-pointer hover:opacity-85"
                    stroke="#09090b"
                    strokeWidth="1.5"
                    onMouseEnter={() => setHoveredPieIndex(idx)}
                    onMouseLeave={() => setHoveredPieIndex(null)}
                  />
                );
              })}
              {/* Inner hole */}
              <circle cx={cx} cy={cy} r={innerR} fill="#18181b" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-zinc-500 text-[9px] uppercase tracking-widest">Total</span>
              <span className="text-xs font-bold text-white font-mono leading-none mt-0.5">
                {fmt(total)}
              </span>
            </div>
          </div>

          <div className="flex-1 flex flex-col gap-2 overflow-hidden">
            {data.slice(0, 5).map((item, idx) => {
              const pct = ((item.value / total) * 100).toFixed(0);
              const color = colors[idx % colors.length];
              return (
                <div key={idx} className="flex items-center justify-between text-xs min-w-0">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
                    <span className="text-zinc-400 truncate font-medium">{item.label}</span>
                  </div>
                  <span className="text-zinc-300 font-mono font-semibold ml-2">{pct}%</span>
                </div>
              );
            })}
            {data.length > 5 && (
              <div className="text-[10px] text-zinc-500 italic mt-1 text-right">
                + {data.length - 5} autres catégories
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderBlock = (block: DashboardBlock, index: number) => {
    switch (block) {
      case "overview":
        return (
          <div key={block} className="group relative bg-[#0e0e15] border border-zinc-800/50 rounded-2xl p-6 transition-all">
            {/* Rearranging HUD overlay */}
            <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-zinc-900 border border-zinc-800 rounded-lg p-1 z-10">
              <button
                onClick={() => moveBlock(index, "up")}
                disabled={index === 0}
                className="p-1 hover:bg-zinc-800 text-zinc-400 disabled:opacity-30 rounded transition-all"
                title="Déplacer vers le haut"
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => moveBlock(index, "down")}
                disabled={index === preferences.dashboardOrder.length - 1}
                className="p-1 hover:bg-zinc-800 text-zinc-400 disabled:opacity-30 rounded transition-all"
                title="Déplacer vers le bas"
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Revenus */}
              <div className="bg-zinc-900/40 border border-zinc-800/40 rounded-xl p-4 flex items-start justify-between">
                <div>
                  <span className="text-zinc-400 text-xs font-semibold uppercase tracking-wider block">Revenus</span>
                  <span className="text-2xl font-bold text-emerald-400 font-mono block mt-1">{fmt(totalIncome)}</span>
                  <span className="text-[10px] text-zinc-500 mt-2 block italic">Période en cours</span>
                </div>
                <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl"><TrendingUp className="w-5 h-5" /></div>
              </div>

              {/* Dépenses */}
              <div className="bg-zinc-900/40 border border-zinc-800/40 rounded-xl p-4 flex items-start justify-between">
                <div>
                  <span className="text-zinc-400 text-xs font-semibold uppercase tracking-wider block">Dépenses</span>
                  <span className="text-2xl font-bold text-rose-400 font-mono block mt-1">{fmt(totalExpense)}</span>
                  <span className="text-[10px] text-zinc-500 mt-2 block italic">Période en cours</span>
                </div>
                <div className="p-2.5 bg-rose-500/10 text-rose-400 rounded-xl"><TrendingDown className="w-5 h-5" /></div>
              </div>

              {/* Solde Cashflow */}
              <div className="bg-zinc-900/40 border border-zinc-800/40 rounded-xl p-4 flex items-start justify-between">
                <div>
                  <span className="text-zinc-400 text-xs font-semibold uppercase tracking-wider block">Solde Période</span>
                  <span className={`text-2xl font-bold font-mono block mt-1 ${balance >= 0 ? "text-blue-400" : "text-rose-400"}`}>
                    {balance >= 0 ? "+" : ""}{fmt(balance)}
                  </span>
                  <span className="text-[10px] text-zinc-500 mt-2 block italic">Income - Expense</span>
                </div>
                <div className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl"><Wallet className="w-5 h-5" /></div>
              </div>

              {/* Patrimoine Total */}
              <div className="bg-zinc-900/40 border border-zinc-800/40 rounded-xl p-4 flex items-start justify-between">
                <div>
                  <span className="text-zinc-400 text-xs font-semibold uppercase tracking-wider block">Patrimoine Total</span>
                  <span className="text-2xl font-bold text-amber-400 font-mono block mt-1">{fmt(totalWealth)}</span>
                  <span className="text-[10px] text-zinc-500 mt-2 block italic">{accounts.length} compte(s)</span>
                </div>
                <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl"><PiggyBank className="w-5 h-5" /></div>
              </div>
            </div>
          </div>
        );

      case "charts":
        return (
          <div key={block} className="group relative bg-[#0e0e15] border border-zinc-800/50 rounded-2xl p-6 transition-all">
            {/* Rearranging HUD overlay */}
            <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-zinc-900 border border-zinc-800 rounded-lg p-1 z-10">
              <button
                onClick={() => moveBlock(index, "up")}
                disabled={index === 0}
                className="p-1 hover:bg-zinc-800 text-zinc-400 disabled:opacity-30 rounded transition-all"
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => moveBlock(index, "down")}
                disabled={index === preferences.dashboardOrder.length - 1}
                className="p-1 hover:bg-zinc-800 text-zinc-400 disabled:opacity-30 rounded transition-all"
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Cashflow timeline chart */}
              <div className="lg:col-span-6 bg-zinc-900/40 border border-zinc-800/40 rounded-xl p-5 flex flex-col justify-between">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                    📈 Evolution du Cashflow
                  </span>
                  <div className="flex items-center gap-3 text-[10px] font-semibold">
                    <span className="flex items-center gap-1 text-emerald-400">● Revenus</span>
                    <span className="flex items-center gap-1 text-rose-400">● Dépenses</span>
                  </div>
                </div>
                {renderCashflowChart()}
              </div>

              {/* Expenses by Category camembert */}
              <div className="lg:col-span-3">
                {renderPieChart("🍕 Dépenses par Catégorie", getExpensesByCategory)}
              </div>

              {/* Expenses by Bank Account camembert */}
              <div className="lg:col-span-3">
                {renderPieChart("🏦 Dépenses par Banque (Compte)", getExpensesByAccount)}
              </div>
            </div>
          </div>
        );

      case "accounts":
        return (
          <div key={block} className="group relative bg-[#0e0e15] border border-zinc-800/50 rounded-2xl p-6 transition-all">
            {/* Rearranging HUD overlay */}
            <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-zinc-900 border border-zinc-800 rounded-lg p-1 z-10">
              <button
                onClick={() => moveBlock(index, "up")}
                disabled={index === 0}
                className="p-1 hover:bg-zinc-800 text-zinc-400 disabled:opacity-30 rounded transition-all"
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => moveBlock(index, "down")}
                disabled={index === preferences.dashboardOrder.length - 1}
                className="p-1 hover:bg-zinc-800 text-zinc-400 disabled:opacity-30 rounded transition-all"
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                🏦 Mes Comptes bancaires ({accounts.length})
              </span>
              <button
                onClick={() => onNavigate("accounts")}
                className="text-xs text-emerald-400 hover:underline hover:text-emerald-300 transition-all font-medium"
              >
                Gérer les comptes →
              </button>
            </div>

            {accounts.length === 0 ? (
              <div className="text-center py-6 text-zinc-500 bg-zinc-900/20 rounded-xl border border-dashed border-zinc-800">
                Aucun compte bancaire. Cliquez sur Gérer les comptes pour en ajouter un.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 animate-fadeIn">
                {accounts.map((acc) => (
                  <div
                    key={acc.id}
                    className="bg-zinc-900/60 border border-zinc-800/70 hover:border-zinc-700/80 rounded-xl p-4 flex flex-col justify-between transition-all"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xl">{acc.emoji || "💵"}</span>
                      <div className="min-w-0">
                        <span className="text-sm font-semibold text-white truncate block">{acc.name}</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[9px] px-1.5 py-0.5 bg-zinc-800 text-zinc-400 rounded">
                            {acc.type}
                          </span>
                          {acc.isMirror && (
                            <span className="text-[9px] px-1.5 py-0.5 bg-indigo-500/15 text-indigo-400 rounded font-medium border border-indigo-500/10">
                              Miroir Local
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-xl font-bold font-mono mt-2 text-emerald-400">
                      {fmt(acc.balance)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case "transactions":
        const recents = filteredTxs.slice(-5).reverse();
        return (
          <div key={block} className="group relative bg-[#0e0e15] border border-zinc-800/50 rounded-2xl p-6 transition-all">
            {/* Rearranging HUD overlay */}
            <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-zinc-900 border border-zinc-800 rounded-lg p-1 z-10">
              <button
                onClick={() => moveBlock(index, "up")}
                disabled={index === 0}
                className="p-1 hover:bg-zinc-800 text-zinc-400 disabled:opacity-30 rounded transition-all"
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => moveBlock(index, "down")}
                disabled={index === preferences.dashboardOrder.length - 1}
                className="p-1 hover:bg-zinc-800 text-zinc-400 disabled:opacity-30 rounded transition-all"
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                💸 Dernières Transactions de la période
              </span>
              <button
                onClick={() => onNavigate("transactions")}
                className="text-xs text-emerald-400 hover:underline hover:text-emerald-300 transition-all font-medium"
              >
                Voir toutes les transactions →
              </button>
            </div>

            {recents.length === 0 ? (
              <div className="text-center py-6 text-zinc-500 bg-zinc-900/20 rounded-xl border border-dashed border-zinc-800">
                Aucune transaction sur cette période.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-zinc-300 border-collapse">
                  <thead>
                    <tr className="border-b border-zinc-800/60 text-zinc-500 uppercase tracking-wider font-semibold">
                      <th className="pb-2.5">Date</th>
                      <th className="pb-2.5">Description</th>
                      <th className="pb-2.5">Compte</th>
                      <th className="pb-2.5">Catégorie</th>
                      <th className="pb-2.5 text-right">Montant</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/40">
                    {recents.map((tx) => {
                      const acc = accounts.find((a) => a.id === tx.accountId);
                      const isExpense = tx.type === "Depense" || tx.type === "Epargne";
                      return (
                        <tr key={tx.id} className="hover:bg-zinc-900/30 transition-all">
                          <td className="py-3 font-mono text-zinc-500">{tx.date}</td>
                          <td className="py-3 font-semibold text-white">{tx.description}</td>
                          <td className="py-3 text-zinc-400 text-[11px] font-medium">
                            {acc ? acc.name : "N/A"}
                          </td>
                          <td className="py-3">
                            <span className="bg-zinc-800/70 text-zinc-300 rounded px-2 py-0.5 font-medium border border-zinc-700/20 text-[10px]">
                              {tx.category}
                            </span>
                          </td>
                          <td
                            className={`py-3 text-right font-mono font-bold ${
                              isExpense ? "text-rose-400" : "text-emerald-400"
                            }`}
                          >
                            {isExpense ? "-" : "+"}{fmt(tx.amount)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Period Selection Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">Tableau de bord</h2>
          <p className="text-zinc-500 text-xs mt-1">
            Gérez vos flux de trésorerie de manière unifiée et personnalisez vos modules à souhait.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {(["all", "month", "year"] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`text-xs px-3 py-1.5 rounded-lg border font-medium cursor-pointer transition-all ${
                period === p
                  ? "bg-emerald-400 text-zinc-950 border-emerald-400 font-bold"
                  : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:border-zinc-700 hover:text-zinc-200"
              }`}
            >
              {p === "all" ? "Toutes périodes" : p === "month" ? "Ce mois" : "Cette année"}
            </button>
          ))}
        </div>
      </div>

      {/* Grid containing arranged user sections */}
      <div className="space-y-6">
        {preferences.dashboardOrder.map((block, idx) => renderBlock(block, idx))}
      </div>
    </div>
  );
}
