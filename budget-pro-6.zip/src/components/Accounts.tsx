import React, { useState } from "react";
import { Account, AccountType } from "../types";
import { Plus, Trash2, Edit3, ShieldAlert, Layers, CheckCircle2 } from "lucide-react";

interface AccountsProps {
  accounts: Account[];
  onAddAccount: (acc: Omit<Account, "id">) => void;
  onDeleteAccount: (id: string) => void;
  onUpdateAccountBalance: (id: string, newBalance: number) => void; // Ajustement direct de solde "Anti-Bug"
  onDuplicateLocalMirror: (id: string) => void; // Mode Miroir Local Sandbox
  incognito: boolean;
}

export default function Accounts({
  accounts,
  onAddAccount,
  onDeleteAccount,
  onUpdateAccountBalance,
  onDuplicateLocalMirror,
  incognito,
}: AccountsProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAdjustModal, setShowAdjustModal] = useState<string | null>(null);

  // Form states
  const [newType, setNewType] = useState<AccountType>("Courant");
  const [newEmoji, setNewEmoji] = useState("🏦");
  const [newName, setNewName] = useState("");
  const [newBalance, setNewBalance] = useState("0");

  const [adjustedBalance, setAdjustedBalance] = useState("");

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    onAddAccount({
      name: newName.trim().toUpperCase(),
      type: newType,
      emoji: newEmoji,
      balance: parseFloat(newBalance) || 0,
    });
    setNewName("");
    setNewBalance("0");
    setShowAddModal(false);
  };

  const handleAdjustBalanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (showAdjustModal && adjustedBalance !== "") {
      onUpdateAccountBalance(showAdjustModal, parseFloat(adjustedBalance) || 0);
      setAdjustedBalance("");
      setShowAdjustModal(null);
    }
  };

  const typeEmojis: { [key in AccountType]: string } = {
    Courant: "🏦",
    Epargne: "🐖",
    Sandbox: "🧪",
    Autre: "💵",
  };

  const fmt = (val: number) => {
    if (incognito) return "••• €";
    return `${val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">Comptes bancaires</h2>
          <p className="text-zinc-500 text-xs mt-1">
            Gérez vos banques d'épargne réelles, vos comptes courants et vos environnements miroir locaux (Sandbox).
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-emerald-400 text-zinc-950 px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-300 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> Ajouter un compte
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {accounts.map((acc) => (
          <div
            key={acc.id}
            className="relative bg-[#0e0e15] border border-zinc-800/60 rounded-2xl p-6 flex flex-col justify-between transition-all hover:border-zinc-700/80 group"
          >
            {/* Header with name and type badge */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl bg-zinc-900 border border-zinc-800 p-2.5 rounded-xl block leading-none">
                  {acc.emoji}
                </span>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-white truncate block">{acc.name}</h3>
                  <div className="flex flex-wrap items-center gap-1.5 mt-1">
                    <span className="text-[9px] font-bold px-2 py-0.5 bg-zinc-900 text-zinc-400 rounded-md uppercase tracking-wider">
                      {acc.type}
                    </span>
                    {acc.isMirror && (
                      <span className="text-[9px] font-bold px-2 py-0.5 bg-indigo-500/10 text-indigo-400 rounded-md border border-indigo-500/10 uppercase tracking-widest leading-none">
                        Miroir Local
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action buttons on hover */}
              <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1.5 transition-all">
                {/* Adjust Balance strictly - Anti Bug */}
                <button
                  onClick={() => {
                    setShowAdjustModal(acc.id);
                    setAdjustedBalance(acc.balance.toString());
                  }}
                  className="p-1.5 hover:bg-zinc-850 text-amber-400 rounded-lg transition-all"
                  title="Ajustement direct de solde (sans fausses opérations)"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>

                {/* Local mirror creator (Sandbox) */}
                {!acc.isMirror && (
                  <button
                    onClick={() => onDuplicateLocalMirror(acc.id)}
                    className="p-1.5 hover:bg-zinc-850 text-indigo-400 rounded-lg transition-all"
                    title="Dupliquer en Miroir Sandbox (100% Hors-ligne)"
                  >
                    <Layers className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  onClick={() => onDeleteAccount(acc.id)}
                  className="p-1.5 hover:bg-zinc-850 text-rose-400 rounded-lg transition-all"
                  title="Supprimer définitivement"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Account balance status */}
            <div className="mt-6 pt-5 border-t border-zinc-800/40">
              <span className="text-zinc-500 text-[10px] uppercase font-bold tracking-wider block">
                Solde actuel disponible
              </span>
              <div className="text-2xl font-black font-mono text-emerald-400 tracking-tight mt-1">
                {fmt(acc.balance)}
              </div>
            </div>

            {/* Note alert on sandbox mirror */}
            {acc.isMirror && (
              <p className="text-[9px] text-zinc-500 italic mt-3 bg-zinc-900/40 p-2 rounded-lg border border-zinc-850">
                ⚠️ Sandbox : Ce compte miroir local est indépendant de la synchronisation cloud et sert d'environnement test.
              </p>
            )}
          </div>
        ))}

        {accounts.length === 0 && (
          <div className="col-span-1 md:col-span-3 text-center py-12 bg-[#0e0e15] border border-dashed border-zinc-805 rounded-2xl flex flex-col items-center justify-center">
            <ShieldAlert className="w-8 h-8 text-zinc-600 mb-3" />
            <p className="text-zinc-400 font-medium text-sm">Aucun compte bancaire existant</p>
            <p className="text-zinc-600 text-xs mt-1 max-w-sm">
              Créez votre premier compte bancaire réel (compte courant, épargne, etc.) pour stocker de la trésorerie.
            </p>
          </div>
        )}
      </div>

      {/* MODAL 1: ADD ACCOUNT */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md transition-all">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative">
            <h3 className="text-base font-bold text-white mb-4">Créer un nouveau compte bancaire</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Type de compte
                </label>
                <select
                  value={newType}
                  onChange={(e) => {
                    const t = e.target.value as AccountType;
                    setNewType(t);
                    setNewEmoji(typeEmojis[t]);
                  }}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                >
                  <option value="Courant">🏦 Compte Courant</option>
                  <option value="Epargne">🐖 Compte Épargne</option>
                  <option value="Sandbox">🧪 Compte Sandbox Test</option>
                  <option value="Autre">💵 Autre</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Emoji du compte
                </label>
                <select
                  value={newEmoji}
                  onChange={(e) => setNewEmoji(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                >
                  <option value="🏦">🏦 Banque</option>
                  <option value="🐖">🐖 Tirelire</option>
                  <option value="🧪">🧪 Tube à essai (Sandbox)</option>
                  <option value="🍕">🍕 Nourriture</option>
                  <option value="⛽">⛽ Essence / Voiture</option>
                  <option value="🎮">🎮 Loisirs / Gaming</option>
                  <option value="🏠">🏠 Maison / Logement</option>
                  <option value="💵">💵 Billets</option>
                  <option value="💳">💳 Carte Bancaire</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Nom du compte
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: CIC PERSONNEL, LIVRET A"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-650 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Solde de départ (€)
                </label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={newBalance}
                  onChange={(e) => setNewBalance(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-650 focus:outline-none focus:border-emerald-400 font-mono"
                />
              </div>

              <div className="flex items-center gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-400 text-zinc-950 text-xs font-bold py-2.5 rounded-xl hover:bg-emerald-300 transition-all cursor-pointer"
                >
                  Ajouter le compte
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-bold py-2.5 rounded-xl hover:text-white transition-all cursor-pointer"
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: ADJUST BALANCE DIRECTLY - Anti-Bug */}
      {showAdjustModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md transition-all">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative">
            <div className="flex items-center gap-2 mb-3">
              <span className="p-1 bg-amber-500/10 text-amber-400 rounded">
                <ShieldAlert className="w-4 h-4" />
              </span>
              <h3 className="text-sm font-bold text-white">Correction du solde global (Anti-Bug)</h3>
            </div>
            <p className="text-zinc-500 text-xs mb-4">
              Cette action modifie directement le solde disponible pour éliminer les décalages comptables.
              <strong className="text-amber-400 block mt-1">
                Aucune transaction fictive ou résiduelle ne sera générée pour cette mise à jour.
              </strong>
            </p>
            <form onSubmit={handleAdjustBalanceSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Nouveau solde précis (€)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={adjustedBalance}
                  onChange={(e) => setAdjustedBalance(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 text-zinc-950 text-xs font-bold py-2.5 rounded-xl hover:bg-amber-400 transition-all cursor-pointer"
                >
                  Enregistrer l'ajustement
                </button>
                <button
                  type="button"
                  onClick={() => setShowAdjustModal(null)}
                  className="flex-1 bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-bold py-2.5 rounded-xl hover:text-white transition-all cursor-pointer"
                >
                  Fermer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
