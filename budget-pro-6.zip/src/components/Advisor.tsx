import React, { useState, useEffect, useRef } from "react";
import { Account, Transaction, Subscription, SavingGoal } from "../types";
import { Send, ShieldAlert, Cpu, Lock, Terminal, RefreshCw, Sparkles } from "lucide-react";

interface AdvisorProps {
  accounts: Account[];
  transactions: Transaction[];
  subscriptions: Subscription[];
  savingGoals: SavingGoal[];
}

interface Message {
  sender: "user" | "ai";
  text: string;
}

export default function Advisor({
  accounts,
  transactions,
  subscriptions,
  savingGoals,
}: AdvisorProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: "ai",
      text: "Bonjour ! Je suis votre conseiller financier virtuel Budget Pro 6. Grâce à mon analyse continue de vos comptes, transactions et objectifs d'épargne, je peux vous aider à formuler des stratégies budgétaires. Posez-moi vos questions !",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  // Rate Limiting States (Max 3 req / 60 seconds)
  const [requestTimestamps, setRequestTimestamps] = useState<number[]>([]);
  const [cooldown, setCooldown] = useState(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom helper
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Cooldown countdown timer logic
  useEffect(() => {
    if (cooldown > 0) {
      const timer = setTimeout(() => setCooldown(cooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [cooldown]);

  // Aggregate user context to feed the AI prompt system
  const buildFinancialContext = () => {
    const totalWealth = accounts.reduce((sum, a) => sum + a.balance, 0);
    const totalIncomes = transactions.filter((t) => t.type === "Revenu").reduce((sum, t) => sum + t.amount, 0);
    const totalExpenses = transactions.filter((t) => t.type === "Depense" || t.type === "Epargne").reduce((sum, t) => sum + t.amount, 0);
    const activeSubCost = subscriptions.filter((s) => s.type === "Depense").reduce((sum, s) => sum + s.amount, 0);

    const accountsStr = accounts.map((a) => `- ${a.name} (${a.type}): ${a.balance.toLocaleString("fr-FR")} €`).join("\n");
    const activeSubsStr = subscriptions.map((s) => `- ${s.name} (${s.frequency}): ${s.amount} € (${s.type})`).join("\n");
    const savingGoalsStr = savingGoals.map((g) => `- ${g.name}: ${g.current}/${g.target} € (Cible)`).join("\n");

    return `
=== SYNTHÈSE DES COMPTES ===
Patrimoine disponible total : ${totalWealth.toLocaleString("fr-FR")} €
Revenus cumulés : ${totalIncomes.toLocaleString("fr-FR")} €
Dépenses cumulées : ${totalExpenses.toLocaleString("fr-FR")} €
Budget abonnements mensuels fixés : ${activeSubCost.toLocaleString("fr-FR")} €

Liste des comptes :
${accountsStr || "Aucun compte bancaire."}

Abonnements / Récurrences actives :
${activeSubsStr || "Aucun abonnement récurrent."}

Objectifs d'épargne fixés :
${savingGoalsStr || "Aucun objectif d'épargne."}
    `.trim();
  };

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || loading || cooldown > 0) return;

    // Check rate limit: 3 requests per 60s
    const now = Date.now();
    const oneMinuteAgo = now - 60000;
    const recentRequests = requestTimestamps.filter((ts) => ts > oneMinuteAgo);

    if (recentRequests.length >= 3) {
      // Calculate how long to wait
      const oldestRecentRequest = recentRequests[0];
      const waitTime = Math.ceil((oldestRecentRequest + 60000 - now) / 1000);
      setCooldown(waitTime);
      alert(`⚠️ Limitation Anti-Spam activée : Vous avez atteint la limite de 3 requêtes par minute.\nVeuillez patienter ${waitTime} secondes.`);
      return;
    }

    // Accept request, update timestamps
    const userQuery = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { sender: "user", text: userQuery }]);
    setRequestTimestamps((prev) => [...prev, now]);
    setLoading(true);

    try {
      const financialContext = buildFinancialContext();
      const response = await fetch("/api/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userQuery,
          context: financialContext,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setMessages((prev) => [...prev, { sender: "ai", text: data.reply || "Je n'ai pas pu formuler de réponse." }]);
      } else {
        setMessages((prev) => [
          ...prev,
          { sender: "ai", text: `⚠️ Erreur serveur : ${data.error || "Impossible d'interroger la clé serveur."}` },
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        { sender: "ai", text: "⚠️ Erreur réseau : impossible de joindre le serveur de conseils financier." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const setSuggestedQuery = (q: string) => {
    setInput(q);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-zinc-850 pb-5">
        <h2 className="text-xl font-bold tracking-tight text-white">Conseiller IA Financier de confiance</h2>
        <p className="text-zinc-500 text-xs mt-1">
          Bénéficiez de rapports analytiques, d'hypothèses de répartition budgétaire et de recommandations d'épargne.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* CHAT INTERACTIVE PANEL */}
        <div className="lg:col-span-8 flex flex-col bg-[#0e0e15] border border-zinc-800/60 rounded-2xl overflow-hidden h-[450px]">
          {/* Header indicator */}
          <div className="bg-zinc-900/50 border-b border-zinc-850 p-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="p-1 px-2.5 bg-emerald-400 text-zinc-950 font-bold rounded-lg text-xs tracking-wider animate-pulse uppercase">
                IA Online
              </span>
              <span className="text-zinc-400 text-xs font-semibold">Conseiller Personnel</span>
            </div>
            <div className="text-[10px] text-zinc-500 font-mono flex items-center gap-1 bg-zinc-950/60 px-2.5 py-1 rounded-full">
              <span>Crédits d'appel :</span>
              <span className="text-emerald-400 font-bold">{3 - requestTimestamps.filter(t => t > Date.now() - 60000).length} / 3 min</span>
            </div>
          </div>

          {/* Messages list */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {messages.map((m, idx) => (
              <div key={idx} className={`flex ${m.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`rounded-2xl p-4 text-xs max-w-[85%] leading-relaxed whitespace-pre-wrap ${
                    m.sender === "user"
                      ? "bg-emerald-400 text-zinc-950 font-semibold rounded-tr-sm"
                      : "bg-zinc-900 border border-zinc-805 text-zinc-200 rounded-tl-sm shadow-md"
                  }`}
                >
                  <p>{m.text}</p>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-zinc-900 border border-zinc-805 rounded-2xl rounded-tl-sm p-4 text-xs text-zinc-400 flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                  <span>Le conseiller IA d'élite analyse vos finances...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input control rows */}
          <div className="p-4 bg-zinc-900/10 border-t border-zinc-850/60 space-y-3">
            {/* Quick Chips suggestions */}
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                "Comment réduire mes coûts d'abonnements ?",
                "Combien de temps avant d'atteindre mes objectifs d'épargne ?",
                "Fais-moi un rapport analytique complet du mois",
                "Quels arbitrages pour économiser 200€ ?",
              ].map((q) => (
                <button
                  key={q}
                  onClick={() => setSuggestedQuery(q)}
                  className="text-[9px] bg-zinc-900 text-zinc-400 border border-zinc-850 hover:border-zinc-700 hover:text-white rounded-lg py-1 px-2 cursor-pointer transition-all truncate max-w-[200px]"
                >
                  {q}
                </button>
              ))}
            </div>

            <form onSubmit={handleSend} className="flex gap-2">
              <input
                type="text"
                disabled={loading || cooldown > 0}
                placeholder={
                  cooldown > 0
                    ? `⚠️ Limitation Anti-Spam active. Veuillez patienter ${cooldown}s...`
                    : "Interrogez le conseiller d'élite (ex: Analyser mes dépenses de la semaine)..."
                }
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 bg-zinc-900 text-white placeholder-zinc-700 text-xs px-3.5 py-3 rounded-xl border border-zinc-800 focus:outline-none focus:border-emerald-400 font-medium"
              />
              <button
                type="submit"
                disabled={!input.trim() || loading || cooldown > 0}
                className="bg-emerald-400 hover:bg-emerald-300 disabled:opacity-30 disabled:hover:bg-emerald-400 text-zinc-950 p-3 rounded-xl cursor-pointer transition-all flex items-center justify-center shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* TECHNICAL ARCHITECTURE REPORT SECTION */}
        <div className="lg:col-span-4 bg-[#0e0e15] border border-zinc-800/60 rounded-2xl p-6 h-fit shrink-0 space-y-4">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-1.5">
            <Cpu className="w-4 h-4 text-emerald-400" /> Architecture Technique IA Gratuite
          </h3>

          <div className="text-xs text-zinc-400 space-y-3.5 leading-relaxed">
            <p>
              Pour répondre à vos exigences de <strong>gratuité totale</strong> et de <strong>protection anti-spam</strong>, l'application s'appuie sur la combinaison d'une API Gemini et d'un Rate Limiter côté client.
            </p>

            <div className="bg-zinc-900/60 border border-zinc-850 p-3.5 rounded-xl space-y-2 font-mono text-[10px] text-zinc-300">
              <div className="flex items-center gap-1.5 font-bold text-white text-xs mb-1">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" /> Schéma d'Exécution
              </div>
              <div className="text-zinc-500">1. Client ➔ Saisie utilisateur avec Rate-Limiter (Max 3/minute)</div>
              <div className="text-zinc-500">2. Client ➔ Synthèse comptable locale compilée</div>
              <div className="text-zinc-500 font-bold text-emerald-400">3. Serveur Express ➔ API Gemini 2.5 (Gratuit)</div>
              <div className="text-zinc-500">4. IA ➔ Analyse &amp; Calculs d'échéances</div>
            </div>

            <div className="space-y-2 mt-4 text-[11px]">
              <div className="flex items-start gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                <span>
                  <strong className="text-zinc-200">Sécurité à la source :</strong> Vos clés d'API ne transitent jamais sur le navigateur de l'utilisateur, éliminant les vols de jetons.
                </span>
              </div>
              <div className="flex items-start gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong className="text-zinc-200">Zéro Frais :</strong> S'appuie sur la version gratuite de Google Gemini. Le serveur Express sert d'encapsulation de proxies.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
