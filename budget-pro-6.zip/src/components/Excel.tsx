import React, { useState } from "react";
import { Account, Transaction, UserPreferences } from "../types";
import { Download, Play, HelpCircle, PencilLine, Sparkles, Check, CheckCircle2 } from "lucide-react";

interface ExcelProps {
  accounts: Account[];
  transactions: Transaction[];
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
  onUpdateTransaction: (id: string, updated: Partial<Transaction>) => void;
  incognito: boolean;
}

export default function Excel({
  accounts,
  transactions,
  preferences,
  onUpdatePreferences,
  onUpdateTransaction,
  incognito,
}: ExcelProps) {
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [selectedAccountId, setSelectedAccountId] = useState<string>("all");
  const [editingColumnKey, setEditingColumnKey] = useState<string | null>(null);
  const [columnLabelInput, setColumnLabelInput] = useState("");

  const [formula, setFormula] = useState("");
  const [formulaOutput, setFormulaOutput] = useState<{
    success: boolean;
    title: string;
    value: string;
    detail?: string;
  } | null>(null);

  // Editable cell state - Strictly avoids duplicating bugs
  const [editingCell, setEditingCell] = useState<{ txId: string } | null>(null);
  const [cellValueInput, setCellValueInput] = useState("");

  const monthNames = [
    "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
    "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
  ];

  // Context emoji dictionary for common categories
  const categoryEmojis: { [key: string]: string } = {
    Salaire: "💰",
    Freelance: "🚀",
    Bonus: "🎁",
    Alimentation: "🍕",
    Transport: "🚗",
    Loisirs: "🎮",
    Maison: "🏠",
    Sante: "⚕️",
    Abonnement: "🔄",
    Course: "🛒",
    Restaurant: "🍔",
    Café: "☕",
    Vacances: "✈️",
    Impôt: "🏦",
    Virement: "⇅",
    Epargne: "🐖",
  };

  const getEmoji = (cat: string) => {
    return categoryEmojis[cat] || "🏷️";
  };

  const getFilteredTransactions = () => {
    return transactions.filter((tx) => {
      const d = new Date(tx.date);
      const yearMatch = d.getFullYear() === selectedYear;
      const accountMatch = selectedAccountId === "all" || tx.accountId === selectedAccountId;
      return yearMatch && accountMatch;
    });
  };

  const currentTxs = getFilteredTransactions();

  // Aggregate data by category and months
  const categoriesList = Array.from(new Set(transactions.map((tx) => tx.category))).filter(Boolean);

  const getMonthlyAggregateByCategory = () => {
    const matrix: { [category: string]: { [month: number]: number } } = {};
    categoriesList.forEach((cat) => {
      matrix[cat] = {};
      for (let m = 0; m < 12; m++) matrix[cat][m] = 0;
    });

    currentTxs.forEach((tx) => {
      const dateObj = new Date(tx.date);
      const monthIdx = dateObj.getMonth();
      if (matrix[tx.category]) {
        matrix[tx.category][monthIdx] += tx.amount;
      }
    });

    return matrix;
  };

  const monthlyMatrix = getMonthlyAggregateByCategory();

  // CSV backup helper
  const handleExportCSV = () => {
    let csv = "ID,Compte,Type,Amount,Date,Category,Description\n";
    transactions.forEach((tx) => {
      const acc = accounts.find((a) => a.id === tx.accountId)?.name || "N/A";
      csv += `"${tx.id}","${acc.replace(/"/g, '""')}","${tx.type}","${tx.amount}","${tx.date}","${tx.category.replace(/"/g, '""')}","${tx.description.replace(/"/g, '""')}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `BudgetPro6_Backup_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Custom Column Name triggers
  const startEditColumn = (key: string, currentLabel: string) => {
    setEditingColumnKey(key);
    setColumnLabelInput(currentLabel);
  };

  const saveColumnName = () => {
    if (editingColumnKey) {
      onUpdatePreferences({
        excelColumnNames: {
          ...preferences.excelColumnNames,
          [editingColumnKey]: columnLabelInput.trim() || preferences.excelColumnNames[editingColumnKey],
        },
      });
      setEditingColumnKey(null);
    }
  };

  // Safe inline-editor submission to avoid duplication bugs
  const handleEditCellStart = (txId: string, currentAmount: number) => {
    setEditingCell({ txId });
    setCellValueInput(currentAmount.toString());
  };

  const handleEditCellSave = () => {
    if (editingCell) {
      const newAmt = parseFloat(cellValueInput);
      if (!isNaN(newAmt) && newAmt >= 0) {
        onUpdateTransaction(editingCell.txId, { amount: newAmt });
      }
      setEditingCell(null);
    }
  };

  // Natural Language Formula Engine
  const executeFormula = () => {
    const raw = formula.trim().toLowerCase();
    if (!raw) return;

    let result = "";
    let title = "";
    let detail = "";
    let success = true;

    if (raw.includes("somme revenus") || raw.includes("somme gains") || raw.includes("total revenus")) {
      const sum = currentTxs.filter((t) => t.type === "Revenu").reduce((s, t) => s + t.amount, 0);
      title = "Somme des revenus de l'année";
      result = `${sum.toLocaleString("fr-FR")} €`;
      detail = `Calculé sur ${currentTxs.filter((t) => t.type === "Revenu").length} opérations créditeuses.`;
    } else if (raw.includes("somme depenses") || raw.includes("somme dépenses") || raw.includes("total depenses")) {
      const sum = currentTxs.filter((t) => t.type === "Depense").reduce((s, t) => s + t.amount, 0);
      title = "Somme des dépenses de l'année";
      result = `${sum.toLocaleString("fr-FR")} €`;
      detail = `Calculé sur ${currentTxs.filter((t) => t.type === "Depense").length} opérations débiteuses.`;
    } else if (raw.includes("bilan") || raw.includes("solde")) {
      const inc = currentTxs.filter((t) => t.type === "Revenu").reduce((s, t) => s + t.amount, 0);
      const exp = currentTxs.filter((t) => t.type === "Depense" || t.type === "Epargne").reduce((s, t) => s + t.amount, 0);
      title = "Flux net annuel (Bilan)";
      result = `${(inc - exp).toLocaleString("fr-FR")} €`;
      detail = `Revenus: +${inc.toLocaleString("fr-FR")} € | Dépenses: -${exp.toLocaleString("fr-FR")} €`;
    } else if (raw.startsWith("cat ") || raw.startsWith("categorie ") || raw.startsWith("catégorie ")) {
      const targetCat = raw.replace(/catégorie |categorie |cat /, "").trim();
      const sum = currentTxs.filter((t) => t.category.toLowerCase() === targetCat).reduce((s, t) => s + t.amount, 0);
      const count = currentTxs.filter((t) => t.category.toLowerCase() === targetCat).length;
      title = `Dépenses dans la catégorie "${targetCat}"`;
      result = `${sum.toLocaleString("fr-FR")} €`;
      detail = `Trouvé ${count} transaction(s) associées.`;
    } else {
      success = false;
      title = "Formule inconnue";
      result = "N/A";
      detail = "Formules acceptées: 'somme revenus', 'somme depenses', 'bilan', 'cat [nom_categorie]' (ex: 'cat alimentation')";
    }

    setFormulaOutput({ success, title, value: result, detail });
  };

  const getColName = (key: string, def: string) => {
    return preferences.excelColumnNames[key] || def;
  };

  const fmt = (val: number) => {
    if (incognito) return "•••";
    return `${val.toLocaleString("fr-FR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €`;
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">Tableau récapitulatif mensuel</h2>
          <p className="text-zinc-500 text-xs mt-1">
            Visualisez et modifiez en grille vos opérations groupées par catégories. Personnalisez les colonnes à votre guise.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Export option */}
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all"
          >
            <Download className="w-4 h-4" /> Sauvegarder CSV
          </button>
        </div>
      </div>

      {/* FILTER CONTROLS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-zinc-900/35 border border-zinc-850 p-4 rounded-2xl">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-bold uppercase tracking-wider">
            <span>Année :</span>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="bg-black border border-zinc-805 rounded-xl px-2.5 py-1 text-xs text-white uppercase focus:outline-none focus:border-emerald-400"
            >
              {[2024, 2025, 2026, 2027].map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-bold uppercase tracking-wider">
            <span>Compte :</span>
            <select
              value={selectedAccountId}
              onChange={(e) => setSelectedAccountId(e.target.value)}
              className="bg-black border border-zinc-805 rounded-xl px-2.5 py-1 text-xs text-white focus:outline-none focus:border-emerald-400"
            >
              <option value="all">Tous les comptes</option>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* NATIONAL FORMULA BAR */}
      <div className="bg-[#0e0e15] border border-zinc-800 p-5 rounded-2xl space-y-3">
        <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" /> Barre de formule naturelle de clôture
        </span>
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Saisissez une formule (ex: 'somme depenses', 'bilan', 'cat alimentation'...)"
            value={formula}
            onChange={(e) => setFormula(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && executeFormula()}
            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-700 font-mono focus:outline-none focus:border-emerald-400"
          />
          <button
            onClick={executeFormula}
            className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-850 px-4 py-2 rounded-xl text-xs font-bold text-emerald-400 cursor-pointer flex items-center gap-1.5 transition-all"
          >
            <Play className="w-3 h-3" /> Appliquer
          </button>
        </div>

        {formulaOutput && (
          <div
            className={`rounded-xl p-3 text-xs leading-relaxed ${
              formulaOutput.success
                ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                : "bg-rose-500/10 border border-rose-500/20 text-rose-400"
            }`}
          >
            <span className="font-bold uppercase tracking-wider text-[10px] block mb-1">
              {formulaOutput.title}
            </span>
            <span className="text-xl font-bold font-mono tracking-tight block">{formulaOutput.value}</span>
            {formulaOutput.detail && <span className="text-[10px] text-zinc-400 mt-1 block font-sans">{formulaOutput.detail}</span>}
          </div>
        )}
      </div>

      {/* GRID CONTAINER - SPREADSHEET */}
      <div className="bg-[#0e0e15] border border-zinc-800/60 rounded-2xl overflow-hidden p-6 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300 border-collapse table-fixed">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-500 uppercase tracking-wider font-semibold">
                <th className="pb-3 w-[150px] truncate">
                  {editingColumnKey === "category" ? (
                    <div className="flex items-center gap-1 bg-black p-1 rounded-md">
                      <input
                        type="text"
                        value={columnLabelInput}
                        onChange={(e) => setColumnLabelInput(e.target.value)}
                        onBlur={saveColumnName}
                        onKeyDown={(e) => e.key === "Enter" && saveColumnName()}
                        className="bg-transparent border-none text-xs text-white outline-none w-full font-bold focus:ring-0"
                      />
                    </div>
                  ) : (
                    <span
                      onClick={() => startEditColumn("category", getColName("category", "Secteur / Rubrique"))}
                      className="cursor-pointer hover:text-white flex items-center gap-1"
                    >
                      {getColName("category", "Rubrique")} <PencilLine className="w-3 h-3 text-zinc-650" />
                    </span>
                  )}
                </th>
                {monthNames.map((name, i) => (
                  <th key={i} className="pb-3 w-[80px] font-mono text-center">
                    {name.slice(0, 4)}
                  </th>
                ))}
                <th className="pb-3 w-[100px] text-right">
                  {editingColumnKey === "total" ? (
                    <div className="flex items-center gap-1 bg-black p-1 rounded-md">
                      <input
                        type="text"
                        value={columnLabelInput}
                        onChange={(e) => setColumnLabelInput(e.target.value)}
                        onBlur={saveColumnName}
                        onKeyDown={(e) => e.key === "Enter" && saveColumnName()}
                        className="bg-transparent border-none text-xs text-white outline-none w-full font-bold focus:ring-0"
                      />
                    </div>
                  ) : (
                    <span
                      onClick={() => startEditColumn("total", getColName("total", "Cumul Total"))}
                      className="cursor-pointer hover:text-white flex items-center gap-1 justify-end"
                    >
                      {getColName("total", "Total")} <PencilLine className="w-3 h-3 text-zinc-650" />
                    </span>
                  )}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-850/40">
              {categoriesList.map((cat) => {
                const matrixVal = monthlyMatrix[cat] || {};
                let rowSum = 0;
                for (let m = 0; m < 12; m++) rowSum += matrixVal[m] || 0;

                return (
                  <tr key={cat} className="hover:bg-zinc-900/10 transition-all">
                    <td className="py-3 font-semibold text-white truncate text-[11px] flex items-center gap-2">
                      <span className="text-sm bg-zinc-900/60 p-1 rounded h-6 w-6 flex items-center justify-center border border-zinc-850">
                        {getEmoji(cat)}
                      </span>
                      <span>{cat}</span>
                    </td>
                    {monthNames.map((_, mId) => {
                      const amountVal = matrixVal[mId] || 0;
                      return (
                        <td key={mId} className="py-3 text-center font-mono text-zinc-500 font-medium">
                          {amountVal > 0 ? (
                            <span className="text-zinc-300">{fmt(amountVal)}</span>
                          ) : (
                            <span className="text-zinc-700/60 font-sans">-</span>
                          )}
                        </td>
                      );
                    })}
                    <td className="py-3 text-right font-mono font-bold text-emerald-400">
                      {fmt(rowSum)}
                    </td>
                  </tr>
                );
              })}

              {categoriesList.length === 0 && (
                <tr>
                  <td colSpan={14} className="text-center py-8 text-zinc-650 italic">
                    Aucune catégorie à afficher pour le moment.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* RECENT MONTHS DETAIL AND CELL MODIFIER LIST */}
        <div className="pt-6 border-t border-zinc-800/40 space-y-4">
          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest block">
            ✏️ Correction individualisée de cellules (Anti-Bug de duplication)
          </span>
          <p className="text-zinc-500 text-xs leading-relaxed">
            Pour modifier le montant d'un enregistrement précis du grand livre, cliquez sur l'icône de stylet ci-dessous.
            <strong className="text-emerald-400 block mt-1">
              Cette interface applique la modification à la source et écarte tout risque de multiplication orpheline.
            </strong>
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[220px] overflow-y-auto pr-2">
            {currentTxs.slice(0, 15).map((tx) => (
              <div
                key={tx.id}
                className="bg-zinc-900/40 border border-zinc-850 rounded-xl p-3 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm bg-zinc-950 p-1 rounded border border-zinc-800/40">
                      {getEmoji(tx.category)}
                    </span>
                    <span className="font-bold text-white text-xs">{tx.description}</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 mt-1 block">
                    {tx.category} • {tx.date}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {editingCell?.txId === tx.id ? (
                    <div className="flex items-center gap-1.5 bg-black rounded-lg border border-emerald-500 p-1">
                      <input
                        type="number"
                        step="0.01"
                        value={cellValueInput}
                        onChange={(e) => setCellValueInput(e.target.value)}
                        className="bg-transparent text-xs text-white w-16 text-right font-mono outline-none focus:ring-0 shrink-0"
                      />
                      <button
                        onClick={handleEditCellSave}
                        className="p-1 text-emerald-400 hover:bg-zinc-900 rounded cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <span className="font-mono font-bold text-zinc-300">{fmt(tx.amount)}</span>
                      <button
                        onClick={() => handleEditCellStart(tx.id, tx.amount)}
                        className="p-1 hover:bg-zinc-850 text-zinc-500 hover:text-white rounded transition-all"
                      >
                        <PencilLine className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
