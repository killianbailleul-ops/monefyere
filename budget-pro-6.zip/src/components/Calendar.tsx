import React, { useState } from "react";
import { Account, Transaction, CalendarNote, UserPreferences } from "../types";
import { ChevronLeft, ChevronRight, FileText, Search, Save, X, MessageSquare } from "lucide-react";

interface CalendarProps {
  accounts: Account[];
  transactions: Transaction[];
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
  calendarNotes: CalendarNote[];
  onSaveCalendarNote: (date: string, note: string) => void;
  incognito: boolean;
}

export default function Calendar({
  accounts,
  transactions,
  preferences,
  onUpdatePreferences,
  calendarNotes,
  onSaveCalendarNote,
  incognito,
}: CalendarProps) {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDayObj, setSelectedDayObj] = useState<string | null>(null); // State for selected modal day YYYY-MM-DD
  const [noteText, setNoteText] = useState("");

  const monthNames = [
    "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
    "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
  ];

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  // Build calendar matrix logic
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);

  // Month offset for monday-indexed matrix
  let startDayOfWeek = firstDayOfMonth.getDay();
  startDayOfWeek = startDayOfWeek === 0 ? 6 : startDayOfWeek - 1; // Align Mon-Sun

  const totalDays = lastDayOfMonth.getDate();

  // Prefix empty array for pre-month offset
  const preDays = Array.from({ length: startDayOfWeek });
  const dayNumbers = Array.from({ length: totalDays }, (_, i) => i + 1);

  const formatDayDate = (day: number) => {
    return `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  };

  const getDayNote = (dateStr: string) => {
    return calendarNotes.find((n) => n.date === dateStr)?.note || "";
  };

  const getDayTransactions = (dateStr: string) => {
    return transactions.filter((tx) => tx.date === dateStr);
  };

  const handleDayClick = (dateStr: string) => {
    setSelectedDayObj(dateStr);
    setNoteText(getDayNote(dateStr));
  };

  const handleSaveNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDayObj) {
      onSaveCalendarNote(selectedDayObj, noteText.trim());
      setSelectedDayObj(null);
    }
  };

  const fmt = (val: number) => {
    if (incognito) return "••• €";
    return `${val.toLocaleString("fr-FR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €`;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">Calendrier &amp; Agenda Budgétaire</h2>
          <p className="text-zinc-500 text-xs mt-1">
            Visualisez vos encaissements et décaissements au jour le jour, et prenez des notes financières quotidiennes.
          </p>
        </div>

        {/* Option to show notes directly on calendars */}
        <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 text-xs">
          <input
            type="checkbox"
            id="showNotesPref"
            checked={preferences.calendarShowNotesDirectly}
            onChange={(e) => onUpdatePreferences({ calendarShowNotesDirectly: e.target.checked })}
            className="rounded border-zinc-750 text-emerald-400 focus:ring-0 cursor-pointer"
          />
          <label htmlFor="showNotesPref" className="text-zinc-400 font-medium cursor-pointer">
            Afficher les commentaires directement sur le calendrier
          </label>
        </div>
      </div>

      {/* MONTH CONTROL HEADERS */}
      <div className="flex items-center justify-between bg-[#0e0e15] border border-zinc-800 p-4 rounded-2xl">
        <h3 className="text-white font-bold text-sm">
          {monthNames[month]} {year}
        </h3>
        <div className="flex items-center gap-1.5">
          <button
            onClick={handlePrevMonth}
            className="p-1.5 bg-zinc-905 border border-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-all cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={handleToday}
            className="text-xs font-semibold px-3 py-1.5 bg-zinc-905 border border-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-all cursor-pointer"
          >
            Aujourd'hui
          </button>
          <button
            onClick={handleNextMonth}
            className="p-1.5 bg-zinc-905 border border-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-all cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* CALENDAR MATRIX */}
      <div className="bg-[#0e0e15] border border-zinc-800/60 rounded-2xl overflow-hidden p-6">
        <div className="grid grid-cols-7 gap-2 text-center text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-3 pb-3 border-b border-zinc-800/40">
          <div>Lun</div>
          <div>Mar</div>
          <div>Mer</div>
          <div>Jeu</div>
          <div>Ven</div>
          <div>Sam</div>
          <div>Dim</div>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {/* Prefix days from previous month */}
          {preDays.map((_, i) => (
            <div key={`pre-${i}`} className="bg-zinc-900/10 min-h-[90px] rounded-xl opacity-20 border border-transparent" />
          ))}

          {/* Days from active month */}
          {dayNumbers.map((day) => {
            const dateStr = formatDayDate(day);
            const txs = getDayTransactions(dateStr);
            const note = getDayNote(dateStr);

            const isToday =
              new Date().getDate() === day &&
              new Date().getMonth() === month &&
              new Date().getFullYear() === year;

            const dayIncomes = txs.filter((t) => t.type === "Revenu");
            const dayExpenses = txs.filter((t) => t.type === "Depense" || t.type === "Epargne");

            return (
              <div
                key={day}
                onClick={() => handleDayClick(dateStr)}
                className={`bg-zinc-900/40 hover:bg-zinc-900/80 hover:border-zinc-700 min-h-[95px] rounded-xl p-2 border transition-all cursor-pointer flex flex-col justify-between ${
                  isToday ? "border-emerald-400 bg-emerald-500/5" : "border-zinc-800/40"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-[10px] font-bold ${isToday ? "text-emerald-400" : "text-zinc-500"}`}>
                    {day}
                  </span>
                  {note && (
                    <span className="w-1.5 h-1.5 bg-amber-400 rounded-full" title="Contient un commentaire" />
                  )}
                </div>

                {/* Day data listing snippet */}
                <div className="mt-1 space-y-1 overflow-hidden max-h-[46px]">
                  {dayIncomes.length > 0 && (
                    <span className="text-[8px] bg-emerald-500/15 text-emerald-400 rounded-md py-0.5 px-1 font-mono font-bold block truncate leading-tight">
                      +{fmt(dayIncomes.reduce((sum, t) => sum + t.amount, 0))}
                    </span>
                  )}
                  {dayExpenses.length > 0 && (
                    <span className="text-[8px] bg-rose-500/15 text-rose-400 rounded-md py-0.5 px-1 font-mono font-bold block truncate leading-tight">
                      -{fmt(dayExpenses.reduce((sum, t) => sum + t.amount, 0))}
                    </span>
                  )}
                </div>

                {/* Direct Post-it note view if preferred */}
                {preferences.calendarShowNotesDirectly && note && (
                  <div className="mt-1 pb-0.5 border-t border-amber-500/10 text-[8px] text-amber-300 font-medium truncate italic leading-tight">
                    💬 {note}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* MODAL: DAILY DETAILS AND COMMENTS */}
      {selectedDayObj && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md transition-all">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-lg rounded-2xl p-6 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-zinc-850 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-white text-sm">🗓️ Agenda - {new Date(selectedDayObj).toLocaleDateString("fr-FR", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</h3>
                <span className="text-[10px] text-zinc-500 font-mono mt-0.5 block">{selectedDayObj}</span>
              </div>
              <button
                onClick={() => setSelectedDayObj(null)}
                className="text-zinc-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Daily transactions */}
            <div className="space-y-3 mb-5">
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider block">
                Opérations du jour ({getDayTransactions(selectedDayObj).length})
              </span>
              <div className="max-h-[140px] overflow-y-auto space-y-1.5 pr-2">
                {getDayTransactions(selectedDayObj).map((tx) => {
                  const acc = accounts.find((a) => a.id === tx.accountId);
                  const isExpense = tx.type === "Depense" || tx.type === "Epargne";
                  return (
                    <div
                      key={tx.id}
                      className="bg-zinc-900/60 border border-zinc-850 rounded-xl p-2.5 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-white block leading-tight">{tx.description}</span>
                        <div className="flex items-center gap-2 text-[10px] text-zinc-500 mt-1 leading-none">
                          <span className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-400 font-medium">
                            {tx.category}
                          </span>
                          <span>•</span>
                          <span>{acc ? acc.name : "N/A"}</span>
                        </div>
                      </div>
                      <span className={`font-mono font-bold ${isExpense ? "text-rose-400" : "text-emerald-400"}`}>
                        {isExpense ? "-" : "+"}{fmt(tx.amount)}
                      </span>
                    </div>
                  );
                })}

                {getDayTransactions(selectedDayObj).length === 0 && (
                  <p className="text-zinc-600 text-xs italic py-2">
                    Aucune transaction programmée à cette date.
                  </p>
                )}
              </div>
            </div>

            {/* Notes/Comments box */}
            <form onSubmit={handleSaveNoteSubmit} className="space-y-3">
              <div>
                <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <MessageSquare className="w-3.5 h-3.5 text-amber-400" /> Note journalière ou commentaire
                </label>
                <textarea
                  placeholder="Ex: Échéance de loyer payée, prime reçue, relance ou simplement memento..."
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white placeholder-zinc-700 min-h-[90px] focus:outline-none focus:border-amber-400 resize-y"
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-amber-400 text-zinc-950 text-xs font-bold py-2.5 rounded-xl hover:bg-amber-300 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Enregistrer la note
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedDayObj(null)}
                  className="flex-1 bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-bold py-2.5 rounded-xl hover:text-white transition-all cursor-pointer"
                >
                  Fermer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
