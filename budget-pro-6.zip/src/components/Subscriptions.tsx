import React, { useState } from "react";
import { Account, Subscription } from "../types";
import { Plus, Trash2, Calendar, Coins, RefreshCw } from "lucide-react";

interface SubscriptionsProps {
  accounts: Account[];
  subscriptions: Subscription[];
  onAddSubscription: (sub: Omit<Subscription, "id">) => void;
  onDeleteSubscription: (id: string) => void;
  categories: { [key: string]: string[] };
  incognito: boolean;
}

export default function Subscriptions({
  accounts,
  subscriptions,
  onAddSubscription,
  onDeleteSubscription,
  categories,
  incognito,
}: SubscriptionsProps) {
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [name, setName] = useState("");
  const [accountId, setAccountId] = useState(accounts[0]?.id || "");
  const [direction, setDirection] = useState<"Revenu" | "Depense">("Depense");
  const [amount, setAmount] = useState("");
  const [frequency, setFrequency] = useState<Subscription["frequency"]>("monthly");
  const [dayOfMonth, setDayOfMonth] = useState<number | null>(null);
  const [category, setCategory] = useState("");
  const [nextDate, setNextDate] = useState(new Date().toISOString().split("T")[0]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!name.trim() || !parsedAmount || parsedAmount <= 0 || !accountId) {
      alert("Veuillez saisir toutes les données requises pour l'abonnement.");
      return;
    }

    onAddSubscription({
      name: name.trim(),
      accountId,
      type: direction,
      amount: parsedAmount,
      frequency,
      dayOfMonth: frequency === "monthly_day" ? dayOfMonth || 1 : null,
      category: category || (categories[direction]?.[0] || "Autre"),
      nextDate,
    });

    // Reset Form
    setName("");
    setAmount("");
    setFrequency("monthly");
    setDayOfMonth(null);
    setShowAddModal(false);
  };

  const fmt = (val: number) => {
    if (incognito) return "••• €";
    return `${val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
  };

  const frequencyLabels: { [key in Subscription["frequency"]]: string } = {
    daily: "Quotidien",
    weekly: "Hebdomadaire",
    monthly: "Mensuel",
    monthly_day: "Le X du mois",
    yearly: "Annuel",
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">Créances &amp; Abonnements récurrents</h2>
          <p className="text-zinc-500 text-xs mt-1">
            Gérez vos salaires réguliers, prélèvements Netflix, abonnements électricité ou charges locatives de façon automatique.
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-emerald-400 text-zinc-950 px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-300 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> Ajouter un abonnement
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {subscriptions.map((sub) => {
          const acc = accounts.find((a) => a.id === sub.accountId);
          const isExpense = sub.type === "Depense";
          return (
            <div
              key={sub.id}
              className="bg-[#0e0e15] border border-zinc-800/60 rounded-2xl p-6 flex flex-col justify-between hover:border-zinc-750 transition-all relative group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-xl leading-none text-xl block">
                    {isExpense ? "🔄" : "📈"}
                  </span>
                  <div>
                    <h3 className="text-sm font-bold text-white leading-tight">{sub.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span
                        className={`text-[9px] font-bold px-2 py-0.5 rounded ${
                          isExpense ? "bg-rose-500/10 text-rose-400" : "bg-emerald-500/10 text-emerald-400"
                        }`}
                      >
                        {isExpense ? "Débit auto" : "Crédit auto"}
                      </span>
                      <span className="text-[10px] text-zinc-500">•</span>
                      <span className="text-[10px] text-zinc-400 font-medium">{sub.category}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <span className={`text-lg font-bold font-mono ${isExpense ? "text-rose-400" : "text-emerald-400"}`}>
                    {isExpense ? "-" : "+"}{fmt(sub.amount)}
                  </span>
                  <button
                    onClick={() => onDeleteSubscription(sub.id)}
                    className="p-1.5 hover:bg-zinc-850 text-zinc-500 hover:text-rose-400 rounded-lg transition-all opacity-0 group-hover:opacity-100 cursor-pointer"
                    title="Supprimer définitivement"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Sub parameters */}
              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-zinc-800/40 text-xs">
                <div className="bg-zinc-900/40 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold text-zinc-500 uppercase block mb-1">Fréquence</span>
                  <span className="text-zinc-300 font-semibold">
                    {frequencyLabels[sub.frequency]}
                    {sub.frequency === "monthly_day" && ` (${sub.dayOfMonth})`}
                  </span>
                </div>
                <div className="bg-zinc-900/40 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold text-zinc-500 uppercase block mb-1">Banque</span>
                  <span className="text-zinc-300 font-semibold truncate block">
                    {acc ? acc.name : "Inconnu"}
                  </span>
                </div>
                <div className="bg-zinc-900/40 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold text-zinc-500 uppercase block mb-1">Prochaine échéance</span>
                  <span className="text-zinc-300 font-semibold flex items-center gap-1 font-mono">
                    <Calendar className="w-3 h-3 text-zinc-500" /> {sub.nextDate}
                  </span>
                </div>
              </div>
            </div>
          )})}

        {subscriptions.length === 0 && (
          <div className="col-span-1 md:col-span-2 text-center py-12 bg-[#0e0e15] border border-dashed border-zinc-805 rounded-2xl flex flex-col items-center justify-center">
            <RefreshCw className="w-8 h-8 text-zinc-600 mb-3 animate-spin duration-3000" />
            <p className="text-zinc-400 font-medium text-sm">Aucun abonnement enregistré</p>
            <p className="text-zinc-600 text-xs mt-1">
              Configurez vos rentrées financières récurrentes ou charges fixes automatiques.
            </p>
          </div>
        )}
      </div>

      {/* MODAL: ADD RECURENCE */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md transition-all">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative">
            <h3 className="text-base font-bold text-white mb-4">Créer un abonnement / flux récurrent</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Libellé de la récurrence
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: NETFLIX, ABONNEMENT EDF, SALAIRE MENSUEL"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Sens du flux
                  </label>
                  <select
                    value={direction}
                    onChange={(e) => {
                      const d = e.target.value as "Revenu" | "Depense";
                      setDirection(d);
                      setCategory(categories[d]?.[0] || "Autre");
                    }}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                  >
                    <option value="Depense">💸 Débit (Charge / Facture)</option>
                    <option value="Revenu">📈 Crédit (Revenus fixes)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Compte à imputer
                  </label>
                  <select
                    value={accountId}
                    onChange={(e) => setAccountId(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                  >
                    <option value="">Sélectionner...</option>
                    {accounts.map((a) => (
                      <option key={a.id} value={a.id}>{a.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Catégorie
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                  >
                    {(categories[direction] || ["Autre"]).map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Fréquence cycle
                  </label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value as Subscription["frequency"])}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                  >
                    <option value="daily">Chaque jour</option>
                    <option value="weekly">Chaque semaine</option>
                    <option value="monthly">Chaque mois</option>
                    <option value="monthly_day">Le X du mois (Précis)</option>
                    <option value="yearly">Chaque année</option>
                  </select>
                </div>
              </div>

              {frequency === "monthly_day" && (
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Jour précis du mois (1 - 31)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    required
                    value={dayOfMonth || ""}
                    onChange={(e) => setDayOfMonth(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 font-mono focus:outline-none focus:border-emerald-400"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Montant (€)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="9.99"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white font-mono placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Première date d'effet
                  </label>
                  <input
                    type="date"
                    required
                    value={nextDate}
                    onChange={(e) => setNextDate(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-400 text-zinc-950 text-xs font-bold py-2.5 rounded-xl hover:bg-emerald-300 cursor-pointer transition-all"
                >
                  Ajouter la récurrence
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-bold py-2.5 rounded-xl hover:text-white transition-all cursor-pointer"
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
