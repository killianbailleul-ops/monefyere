import React, { useState } from "react";
import { Account, Transaction, SavingGoal } from "../types";
import { Plus, Trash2, Calendar, FileText, ArrowUpDown, Coins } from "lucide-react";

interface TransactionsProps {
  accounts: Account[];
  transactions: Transaction[];
  savingGoals: SavingGoal[];
  onAddTransaction: (tx: Omit<Transaction, "id">) => void;
  onDeleteTransaction: (id: string) => void;
  categories: { [key: string]: string[] };
  incognito: boolean;
}

export default function Transactions({
  accounts,
  transactions,
  savingGoals,
  onAddTransaction,
  onDeleteTransaction,
  categories,
  incognito,
}: TransactionsProps) {
  const [selectedMonth, setSelectedMonth] = useState<string>("all");

  // Form states
  const [accountId, setAccountId] = useState(accounts[0]?.id || "");
  const [type, setType] = useState<"Revenu" | "Depense" | "Transfert" | "Epargne">("Depense");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [linkedSavingId, setLinkedSavingId] = useState<string>("");

  // Transfer states
  const [transferFromId, setTransferFromId] = useState("");
  const [transferToId, setTransferToId] = useState("");

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!parsedAmount || parsedAmount <= 0) {
      alert("Veuillez saisir un montant valide supérieur à 0.");
      return;
    }

    if (type === "Transfert") {
      if (!transferFromId || !transferToId || transferFromId === transferToId) {
        alert("Veuillez choisir deux comptes émetteurs et récepteurs différents.");
        return;
      }
      onAddTransaction({
        accountId: transferFromId,
        type: "Transfert",
        amount: parsedAmount,
        description: `Transfert vers ${accounts.find((a) => a.id === transferToId)?.name || ""}`,
        category: "Virement",
        date,
      });
      onAddTransaction({
        accountId: transferToId,
        type: "Transfert",
        amount: parsedAmount,
        description: `Transfert reçu de ${accounts.find((a) => a.id === transferFromId)?.name || ""}`,
        category: "Virement",
        date,
      });
    } else {
      if (!accountId) {
        alert("Veuillez choisir un compte associé.");
        return;
      }
      onAddTransaction({
        accountId,
        type,
        amount: parsedAmount,
        description: description.trim() || type,
        category: category || (categories[type]?.[0] || "Autre"),
        date,
        savingsId: type === "Epargne" ? linkedSavingId || null : null,
      });
    }

    // Reset Form
    setAmount("");
    setDescription("");
    setLinkedSavingId("");
  };

  // Month select options generation (last 12 Months)
  const getMonthOptions = () => {
    const options: { value: string; label: string }[] = [];
    const now = new Date();
    const monthNames = [
      "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
      "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
    ];

    for (let i = 0; i < 12; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const val = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const lbl = `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
      options.push({ value: val, label: lbl });
    }
    return options;
  };

  const monthOptions = getMonthOptions();

  // Get current transactions based on month filter
  const getFilteredTransactions = () => {
    return transactions.filter((tx) => {
      if (selectedMonth === "all") return true;
      const d = new Date(tx.date);
      const filterStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      return filterStr === selectedMonth;
    });
  };

  const filteredTxs = getFilteredTransactions().slice().reverse();

  // Calculate quick metrics for selected month
  const monthIncome = filteredTxs
    .filter((t) => t.type === "Revenu")
    .reduce((sum, t) => sum + t.amount, 0);

  const monthExpense = filteredTxs
    .filter((t) => t.type === "Depense" || t.type === "Epargne")
    .reduce((sum, t) => sum + t.amount, 0);

  const fmt = (val: number) => {
    if (incognito) return "••• €";
    return `${val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-zinc-850 pb-5">
        <h2 className="text-xl font-bold tracking-tight text-white">Transactions de trésorerie</h2>
        <p className="text-zinc-500 text-xs mt-1">
          Ajoutez vos revenus, dépenses, effectuez des virements entre vos comptes ou alimentez vos objectifs d'épargne.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* FORM PANEL */}
        <div className="lg:col-span-4 bg-[#0e0e15] border border-zinc-800/50 rounded-2xl p-6 h-fit shrink-0">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <Coins className="w-4 h-4 text-emerald-400" /> Saisie rapide d'opération
          </h3>

          <form onSubmit={handleAddSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                Type de transaction
              </label>
              <div className="grid grid-cols-4 gap-1.5 bg-zinc-900/50 p-1 rounded-xl">
                {(["Depense", "Revenu", "Epargne", "Transfert"] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => {
                      setType(t);
                      if (t !== "Transfert") {
                        setCategory(categories[t]?.[0] || "Autre");
                      }
                    }}
                    className={`text-[10px] font-semibold py-1.5 px-1 rounded-lg transition-all cursor-pointer text-center ${
                      type === t
                        ? "bg-emerald-400 text-zinc-950 font-bold"
                        : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    {t === "Depense" ? "Déb" : t === "Revenu" ? "Créd" : t === "Epargne" ? "Épa" : "Vir"}
                  </button>
                ))}
              </div>
            </div>

            {type === "Transfert" ? (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                    Émetteur
                  </label>
                  <select
                    value={transferFromId}
                    onChange={(e) => setTransferFromId(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-805 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-405"
                  >
                    <option value="">Sélectionner...</option>
                    {accounts.map((a) => (
                      <option key={a.id} value={a.id}>{a.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                    Récepteur
                  </label>
                  <select
                    value={transferToId}
                    onChange={(e) => setTransferToId(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-805 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-405"
                  >
                    <option value="">Sélectionner...</option>
                    {accounts.map((a) => (
                      <option key={a.id} value={a.id}>{a.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                    Compte bancaire
                  </label>
                  <select
                    value={accountId}
                    onChange={(e) => setAccountId(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-805 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-405"
                  >
                    <option value="">Sélectionner...</option>
                    {accounts.map((a) => (
                      <option key={a.id} value={a.id}>{a.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                    Catégorie
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-805 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-405"
                  >
                    {(categories[type] || ["Autre"]).map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {type === "Epargne" && (
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                  Lier à un objectif d'épargne
                </label>
                <select
                  value={linkedSavingId}
                  onChange={(e) => setLinkedSavingId(e.target.value)}
                  required
                  className="w-full bg-zinc-900 border border-zinc-805 rounded-xl px-2.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-405"
                >
                  <option value="">Sélectionner l'objectif...</option>
                  {savingGoals.map((sg) => (
                    <option key={sg.id} value={sg.id}>{sg.name}</option>
                  ))}
                </select>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                  Montant en euro (€)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-805 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-405 font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                  Date de valeur
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-805 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-405 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5">
                Libellé / Note explicative
              </label>
              <input
                type="text"
                placeholder="Ex: Courses mensuelles, Salaire, Virement..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-850 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-400 text-zinc-950 font-bold py-2.5 rounded-xl text-xs hover:bg-emerald-300 cursor-pointer transition-all pt-3 mt-2"
            >
              Enregistrer l'opération
            </button>
          </form>
        </div>

        {/* LIST & FILTER PANEL */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-zinc-900/35 border border-zinc-850 p-4 rounded-2xl">
            <div className="flex items-center gap-2">
              <span className="text-zinc-500 text-xs font-bold uppercase tracking-wider">Filtrer par mois :</span>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white font-medium focus:outline-none focus:border-emerald-400"
              >
                <option value="all">Toutes périodes</option>
                {monthOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
            {/* Quick metrics info panel */}
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="text-right">
                <span className="text-zinc-500 text-[10px] uppercase font-bold tracking-wider block">Crédits</span>
                <span className="text-emerald-400 font-bold">{fmt(monthIncome)}</span>
              </div>
              <div className="text-right">
                <span className="text-zinc-500 text-[10px] uppercase font-bold tracking-wider block">Débits</span>
                <span className="text-rose-400 font-bold">{fmt(monthExpense)}</span>
              </div>
              <div className="text-right border-l border-zinc-800 pl-4">
                <span className="text-zinc-500 text-[10px] uppercase font-bold tracking-wider block">Bilan</span>
                <span className={`font-bold ${monthIncome - monthExpense >= 0 ? "text-blue-400" : "text-rose-400"}`}>
                  {monthIncome - monthExpense >= 0 ? "+" : ""}{fmt(monthIncome - monthExpense)}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-[#0e0e15] border border-zinc-800/50 rounded-2xl p-6">
            {filteredTxs.length === 0 ? (
              <div className="text-center py-12 text-zinc-500 italic text-xs">
                Aucune transaction enregistrée pour ce mois.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-zinc-300 border-collapse">
                  <thead>
                    <tr className="border-b border-zinc-800 text-zinc-500 uppercase tracking-wider font-semibold">
                      <th className="pb-3 text-center w-8">Type</th>
                      <th className="pb-3 pl-3">Détail</th>
                      <th className="pb-3">Compte</th>
                      <th className="pb-3">Catégorie</th>
                      <th className="pb-3 text-right">Montant</th>
                      <th className="pb-3 text-center w-10">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/40">
                    {filteredTxs.map((tx) => {
                      const acc = accounts.find((a) => a.id === tx.accountId);
                      const isMinus = tx.type === "Depense" || tx.type === "Epargne";
                      return (
                        <tr key={tx.id} className="hover:bg-zinc-900/20 group transition-all">
                          <td className="py-3 text-center">
                            <span
                              className={`w-2.5 h-2.5 rounded-full inline-block ${
                                tx.type === "Revenu"
                                  ? "bg-emerald-400"
                                  : tx.type === "Depense"
                                  ? "bg-rose-405"
                                  : tx.type === "Epargne"
                                  ? "bg-amber-400"
                                  : "bg-blue-400"
                              }`}
                              title={tx.type}
                            />
                          </td>
                          <td className="py-3 pl-3">
                            <div>
                              <span className="font-semibold text-white text-xs block leading-tight">
                                {tx.description}
                              </span>
                              <span className="text-[10px] text-zinc-500 font-mono mt-0.5 block leading-none flex items-center gap-1">
                                <Calendar className="w-3 h-3" /> {tx.date}
                              </span>
                            </div>
                          </td>
                          <td className="py-3 text-zinc-400 text-[11px] font-medium font-sans">
                            {acc ? acc.name : "N/A"}
                          </td>
                          <td className="py-3 text-zinc-400">
                            <span className="bg-zinc-900 text-zinc-300 rounded px-1.5 py-0.5 font-medium border border-zinc-800/30 text-[10px]">
                              {tx.category}
                            </span>
                          </td>
                          <td
                            className={`py-3 text-right font-mono font-bold text-xs ${
                              isMinus ? "text-rose-400" : tx.type === "Transfert" ? "text-blue-400" : "text-emerald-400"
                            }`}
                          >
                            {isMinus ? "-" : tx.type === "Transfert" ? "⇅ " : "+"}{fmt(tx.amount)}
                          </td>
                          <td className="py-3 text-center">
                            <button
                              onClick={() => onDeleteTransaction(tx.id)}
                              className="text-zinc-500 hover:text-rose-400 p-1 rounded transition-all opacity-0 group-hover:opacity-100"
                              title="Supprimer cette transaction"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
