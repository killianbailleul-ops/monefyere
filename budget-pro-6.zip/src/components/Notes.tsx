import React, { useState } from "react";
import { Plus, Trash2, ShieldAlert, Key, Eye, EyeOff, Copy, CheckCircle2 } from "lucide-react";

interface Note {
  id: string;
  title: string;
  login?: string;
  password?: string;
  text?: string;
  cat: string;
  updated: string;
}

interface NotesProps {
  notes: Note[];
  onAddNote: (note: Omit<Note, "id" | "updated">) => void;
  onDeleteNote: (id: string) => void;
}

export default function Notes({ notes, onAddNote, onDeleteNote }: NotesProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPassMap, setShowPassMap] = useState<{ [id: string]: boolean }>({});

  // Form states
  const [title, setTitle] = useState("");
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [text, setText] = useState("");
  const [cat, setCat] = useState("Autre");

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 1800);
  };

  const handleCopy = (textToCopy: string, label: string) => {
    navigator.clipboard.writeText(textToCopy);
    triggerToast(`${label} copié !`);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAddNote({
      title: title.trim(),
      login: login.trim() || undefined,
      password: password || undefined,
      text: text.trim() || undefined,
      cat,
    });

    setTitle("");
    setLogin("");
    setPassword("");
    setText("");
    setCat("Autre");
    setShowAddModal(false);
  };

  const catColors: { [key: string]: string } = {
    Banque: "bg-blue-500/10 text-blue-400 border-blue-500/10",
    Email: "bg-emerald-500/10 text-emerald-400 border-emerald-500/10",
    Streaming: "bg-purple-500/10 text-purple-400 border-purple-500/10",
    Shopping: "bg-orange-500/10 text-orange-400 border-orange-500/10",
    Reseaux: "bg-rose-500/10 text-rose-400 border-rose-500/10",
    Autre: "bg-zinc-800/10 text-zinc-400 border-zinc-800/20",
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">Coffre-fort Notes &amp; Mots de passe</h2>
          <p className="text-zinc-500 text-xs mt-1">
            Enregistrez localement de manière ultra sécurisée vos identifiants ou remarques secrètes. Vos clés restent chiffrées sur votre navigateur.
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-emerald-400 text-zinc-950 px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-300 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> Ajouter un identifiant
        </button>
      </div>

      {toastMessage && (
        <div className="fixed top-6 right-6 bg-emerald-400 text-zinc-950 px-5 py-3 rounded-xl font-bold text-xs shadow-2xl z-50 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" /> {toastMessage}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {notes.map((n) => {
          const showPass = !!showPassMap[n.id];
          return (
            <div
              key={n.id}
              className="bg-[#0e0e15] border border-zinc-800/60 rounded-2xl p-6 hover:border-zinc-750 transition-all relative group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-xl leading-none text-xl block">
                      🗝️
                    </span>
                    <div>
                      <h3 className="text-sm font-bold text-white leading-tight">{n.title}</h3>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded border inline-block mt-2 ${catColors[n.cat] || catColors.Autre}`}>
                        {n.cat}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => onDeleteNote(n.id)}
                    className="p-1 text-zinc-500 hover:text-rose-450 rounded-lg opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                    title="Supprimer définitivement"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Fields */}
                <div className="space-y-3.5 pt-4 border-t border-zinc-805/40 text-xs">
                  {n.login && (
                    <div className="bg-zinc-900/40 rounded-xl p-3 flex items-center justify-between border border-zinc-850/40">
                      <div>
                        <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-wider block">ID / Email</span>
                        <span className="text-zinc-300 font-semibold font-mono block mt-1 truncate max-w-[200px]">{n.login}</span>
                      </div>
                      <button
                        onClick={() => handleCopy(n.login || "", "Identifiant")}
                        className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded transition-all cursor-pointer"
                        title="Copier"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {n.password && (
                    <div className="bg-zinc-900/40 rounded-xl p-3 flex items-center justify-between border border-zinc-850/40">
                      <div>
                        <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-wider block">Mot de passe de session</span>
                        <span className="text-zinc-300 font-semibold font-mono block mt-1 tracking-wider">
                          {showPass ? n.password : "••••••••••••"}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setShowPassMap({ ...showPassMap, [n.id]: !showPass })}
                          className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded transition-all cursor-pointer"
                          title="Révéler"
                        >
                          {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                        <button
                          onClick={() => handleCopy(n.password || "", "Mot de passe")}
                          className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded transition-all cursor-pointer"
                          title="Copier"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}

                  {n.text && (
                    <div className="bg-zinc-900/20 rounded-xl p-3 border border-zinc-850/40">
                      <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-wider block mb-1">Détails libres</span>
                      <p className="text-zinc-400 text-xs italic font-medium leading-relaxed font-sans">{n.text}</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="text-[9px] text-zinc-600 mt-4 text-right">
                Actualisé le : {n.updated}
              </div>
            </div>
          )})}

        {notes.length === 0 && (
          <div className="col-span-1 md:col-span-2 text-center py-12 bg-[#0e0e15] border border-dashed border-zinc-805 rounded-2xl flex flex-col items-center justify-center">
            <Key className="w-8 h-8 text-zinc-600 mb-3" />
            <p className="text-zinc-400 font-medium text-sm">Le coffre-fort de mots de passe est vide</p>
            <p className="text-zinc-600 text-xs mt-1">
              Enregistrez vos codes de cartes bleues, connexions netflix ou questions d'identité de façon isolée et robuste.
            </p>
          </div>
        )}
      </div>

      {/* MODAL: ADD PASSWORD NOTE */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md transition-all">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative">
            <h3 className="text-base font-bold text-white mb-4">Ajouter un enregistrement coffre-fort</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Titre / Service
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Netflix, Assurance CIC, Compte Amazon"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Identifiant / Email
                  </label>
                  <input
                    type="text"
                    placeholder="samy@corp.com"
                    value={login}
                    onChange={(e) => setLogin(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Mot de passe associé
                  </label>
                  <input
                    type="text"
                    placeholder="••••••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Rubrique
                  </label>
                  <select
                    value={cat}
                    onChange={(e) => setCat(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                  >
                    <option value="Banque">🏦 Banque / Assurance</option>
                    <option value="Email">📧 Email / Communications</option>
                    <option value="Streaming">📺 Divertissement / Streaming</option>
                    <option value="Shopping">🛒 Commerce / Achats</option>
                    <option value="Reseaux">📱 Réseaux sociaux</option>
                    <option value="Autre">📝 Autre billet libre</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Remarques libres / Notes
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Code d'API confidentiel, carte de réserve..."
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-400 text-zinc-950 text-xs font-bold py-2.5 rounded-xl hover:bg-emerald-300 cursor-pointer transition-all"
                >
                  Ajouter au coffre
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-bold py-2.5 rounded-xl hover:text-white transition-all cursor-pointer"
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
