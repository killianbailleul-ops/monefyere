import React, { useState } from "react";
import { Plus, Trash2, ShieldAlert, KeyRound, Sparkles, CheckCircle } from "lucide-react";

interface SettingsProps {
  categories: { [key: string]: string[] };
  onAddCategory: (type: string, catName: string) => void;
  onDeleteCategory: (type: string, catName: string) => void;
  onResetPassword: (current: string, next: string) => boolean;
  onPurgeAllUserData: () => void; // RGPD Suppression définitive en cascade
}

export default function Settings({
  categories,
  onAddCategory,
  onDeleteCategory,
  onResetPassword,
  onPurgeAllUserData,
}: SettingsProps) {
  // Form Categories States
  const [newRevenuCat, setNewRevenuCat] = useState("");
  const [newDepenseCat, setNewDepenseCat] = useState("");

  // Key states
  const [currentPass, setCurrentPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");

  const handleRevenuSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRevenuCat.trim()) return;
    onAddCategory("Revenu", newRevenuCat.trim());
    setNewRevenuCat("");
  };

  const handleDepenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDepenseCat.trim()) return;
    onAddCategory("Depense", newDepenseCat.trim());
    setNewDepenseCat("");
  };

  const handlePassReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPass) return;
    if (newPass !== confirmPass) {
      alert("La confirmation du mot de passe ne correspond pas.");
      return;
    }

    const ok = onResetPassword(currentPass, newPass);
    if (ok) {
      alert("Votre mot de passe a été modifié avec succès.");
      setCurrentPass("");
      setNewPass("");
      setConfirmPass("");
    } else {
      alert("Le mot de passe actuel saisi est incorrect.");
    }
  };

  const handlePurgeClick = () => {
    const confirmation1 = confirm(
      "🗑️ DROIT À L'OUBLI RGPD - SUPPRESSION EN CASCADE\n\nAttention ! Vous demandez la PURGE TOTALE de vos profils administratifs.\n\nCette action supprimera :\n- Vos profils locaux et mots de passe session\n- Vos comptes bancaires attachés\n- Vos relevés et historiques complets de transactions\n- Vos créances & abonnements récurrents\n- Vos objectifs d'épargne et contributions de placements\n\nCette action est irréversible. Voulez-vous continuer ?"
    );
    if (!confirmation1) return;

    const confirmation2 = prompt(
      "Pour confirmer l'effacement définitif et l'écrasement en cascade, veuillez écrire 'SUPPRIMER' ci-dessous :"
    );
    if (confirmation2 !== "SUPPRIMER") {
      alert("Action refusée. Saisie incorrecte.");
      return;
    }

    onPurgeAllUserData();
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-zinc-850 pb-5">
        <h2 className="text-xl font-bold tracking-tight text-white">Paramètres généraux d'administration</h2>
        <p className="text-zinc-500 text-xs mt-1">
          Ajustez vos préférences d'en-tête, configurez vos mots de passe d'authentification ou demandez la suppression en cascade.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* REVENU CATEGORIES PANEL */}
        <div className="bg-[#0e0e15] border border-zinc-800/60 rounded-2xl p-6 space-y-4">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
            📊 Catégories de crédits (Revenu)
          </h3>

          <form onSubmit={handleRevenuSubmit} className="flex gap-2">
            <input
              type="text"
              required
              placeholder="Ex: Freelance, Dividendes..."
              value={newRevenuCat}
              onChange={(e) => setNewRevenuCat(e.target.value)}
              className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
            />
            <button
              type="submit"
              className="bg-zinc-900 hover:bg-zinc-800 text-emerald-400 font-bold border border-zinc-850 py-2 px-4 rounded-xl text-xs cursor-pointer transition-all"
            >
              Ajouter
            </button>
          </form>

          <div className="flex flex-wrap gap-2">
            {(categories.Revenu || []).map((cat) => (
              <span
                key={cat}
                className="bg-zinc-905 border border-zinc-850 text-zinc-300 rounded-xl px-3 py-1.5 text-xs flex items-center gap-1.5"
              >
                {cat}
                <button
                  type="button"
                  onClick={() => onDeleteCategory("Revenu", cat)}
                  className="text-zinc-500 hover:text-rose-450 cursor-pointer font-bold shrink-0 text-[10px]"
                >
                  X
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* DEPENSE CATEGORIES PANEL */}
        <div className="bg-[#0e0e15] border border-zinc-800/60 rounded-2xl p-6 space-y-4">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
            💸 Catégories de débits (Dépense)
          </h3>

          <form onSubmit={handleDepenseSubmit} className="flex gap-2">
            <input
              type="text"
              required
              placeholder="Ex: Livraisons, Cadeaux, Vêtements..."
              value={newDepenseCat}
              onChange={(e) => setNewDepenseCat(e.target.value)}
              className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
            />
            <button
              type="submit"
              className="bg-zinc-900 hover:bg-zinc-800 text-emerald-400 font-bold border border-zinc-850 py-2 px-4 rounded-xl text-xs cursor-pointer transition-all"
            >
              Ajouter
            </button>
          </form>

          <div className="flex flex-wrap gap-2">
            {(categories.Depense || []).map((cat) => (
              <span
                key={cat}
                className="bg-zinc-905 border border-zinc-850 text-zinc-300 rounded-xl px-3 py-1.5 text-xs flex items-center gap-1.5"
              >
                {cat}
                <button
                  type="button"
                  onClick={() => onDeleteCategory("Depense", cat)}
                  className="text-zinc-500 hover:text-rose-450 cursor-pointer font-bold shrink-0 text-[10px]"
                >
                  X
                </button>
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* SECURE PASSWORD CONTROL */}
        <div className="bg-[#0e0e15] border border-zinc-800/60 rounded-2xl p-6 space-y-4">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
            🔐 Administration d'accès session
          </h3>

          <form onSubmit={handlePassReset} className="space-y-3.5">
            <div>
              <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">
                Mot de passe actuel de session
              </label>
              <input
                type="password"
                required
                placeholder="••••••••••••"
                value={currentPass}
                onChange={(e) => setCurrentPass(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">
                  Nouveau mot de passe
                </label>
                <input
                  type="password"
                  required
                  placeholder="••••••••••••"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">
                  Confirmer nouveau
                </label>
                <input
                  type="password"
                  required
                  placeholder="••••••••••••"
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-zinc-900 hover:bg-zinc-800 text-emerald-400 border border-zinc-850 font-bold py-2.5 rounded-xl text-xs cursor-pointer transition-all flex items-center justify-center gap-1.5"
            >
              <KeyRound className="w-4 h-4" /> Sauvegarder le mot de passe
            </button>
          </form>
        </div>

        {/* CASCADING PUGER - GDPR Zone */}
        <div className="bg-[#0e0e15] border border-rose-500/10 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-rose-450 uppercase tracking-widest flex items-center gap-2">
              ⚠️ Zone de purge administrative (RGPD)
            </h3>
            <p className="text-zinc-500 text-xs mt-3 leading-relaxed">
              En accord avec le Règlement Général sur la Protection des Données (RGPD), vous disposez du droit d'effacement inconditionnel de vos données d'administration.
            </p>
            <p className="text-rose-400/85 text-xs mt-3 flex items-start gap-1.5 leading-relaxed">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                <strong>Extinction en cascade :</strong> L'action de suppression définitive purge immédiatement et en cascade toutes vos métadonnées (transactions, d'épargne réelles, budgets, abonnements réguliers, mementos d'agenda). Aucune trace résiduelle n'est conservée.
              </span>
            </p>
          </div>

          <button
            onClick={handlePurgeClick}
            className="w-full bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-550/20 font-bold py-2.5 rounded-xl text-xs cursor-pointer transition-all mt-6"
          >
            🗑️ Purge définitive de mon profil
          </button>
        </div>
      </div>
    </div>
  );
}
