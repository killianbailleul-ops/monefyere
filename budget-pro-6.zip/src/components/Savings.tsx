import React, { useState } from "react";
import { Account, SavingGoal } from "../types";
import { Plus, Trash2, PiggyBank, GraduationCap, Compass, HelpCircle } from "lucide-react";

interface SavingsProps {
  accounts: Account[];
  savingGoals: SavingGoal[];
  onAddSavingGoal: (goal: Omit<SavingGoal, "id">) => void;
  onDeleteSavingGoal: (id: string) => void;
  incognito: boolean;
}

export default function Savings({
  accounts,
  savingGoals,
  onAddSavingGoal,
  onDeleteSavingGoal,
  incognito,
}: SavingsProps) {
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [name, setName] = useState("");
  const [target, setTarget] = useState("");
  const [linkedAccountId, setLinkedAccountId] = useState("");

  // Only real bank accounts of type "Epargne" can be linked
  const epargneAccounts = accounts.filter((a) => a.type === "Epargne");

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedTarget = parseFloat(target);
    if (!name.trim() || !parsedTarget || parsedTarget <= 0 || !linkedAccountId) {
      alert("Veuillez saisir toutes les données d'objectif.");
      return;
    }

    const linkedAccObj = accounts.find((a) => a.id === linkedAccountId);
    if (!linkedAccObj || linkedAccObj.type !== "Epargne") {
      alert("Erreur de liaison : le compte associé doit être un compte d'épargne réel.");
      return;
    }

    // Capture initial value from linked account balance (synced logic)
    onAddSavingGoal({
      name: name.trim(),
      target: parsedTarget,
      current: linkedAccObj.balance,
      linkedAccountId,
    });

    setName("");
    setTarget("");
    setLinkedAccountId("");
    setShowAddModal(false);
  };

  const fmt = (val: number) => {
    if (incognito) return "••• €";
    return `${val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">Objectifs d'Épargne &amp; Placements</h2>
          <p className="text-zinc-500 text-xs mt-1">
            Définissez vos projets (vacances, apport immobilier, sécurité) et liez-les à vos comptes d'épargne réels pour un suivi synchronisé en temps réel.
          </p>
        </div>
        <button
          onClick={() => {
            if (epargneAccounts.length === 0) {
              alert(
                "Liaison obligatoire d'Épargne active :\n\nVeuillez créer au moins un compte de type 'Épargne' dans l'onglet des Comptes avant de planifier un objectif d'épargne."
              );
              return;
            }
            setShowAddModal(true);
            setLinkedAccountId(epargneAccounts[0]?.id || "");
          }}
          className="flex items-center gap-2 bg-emerald-400 text-zinc-950 px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-300 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> Créer un objectif
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {savingGoals.map((goal) => {
          // Sync with active linked Epargne bank account balance
          const linkedAcc = accounts.find((a) => a.id === goal.linkedAccountId);
          const currentProgressAmount = linkedAcc ? linkedAcc.balance : goal.current;
          const progressPercentage = Math.min(
            (currentProgressAmount / goal.target) * 100,
            100
          );

          return (
            <div
              key={goal.id}
              className="bg-[#0e0e15] border border-zinc-800/60 rounded-2xl p-6 hover:border-zinc-750 transition-all relative group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-xl leading-none text-xl block">
                      🐖
                    </span>
                    <div>
                      <h3 className="text-sm font-bold text-white leading-tight">{goal.name}</h3>
                      <span className="text-[10px] text-zinc-500 block mt-1">
                        Lié à : <strong className="text-amber-400">{linkedAcc ? linkedAcc.name : "Compte débranché"}</strong>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <button
                      onClick={() => onDeleteSavingGoal(goal.id)}
                      className="p-1.5 hover:bg-zinc-850 text-zinc-500 hover:text-rose-400 rounded-lg transition-all opacity-0 group-hover:opacity-100 cursor-pointer text-xs"
                      title="Supprimer définitivement"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Progress bar info */}
                <div className="space-y-2 mt-4">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-zinc-500">Progression</span>
                    <span className="text-emerald-400">
                      {progressPercentage.toFixed(1)}% ({fmt(currentProgressAmount)} / {fmt(goal.target)})
                    </span>
                  </div>

                  <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-850/60 p-0.5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-blue-500 transition-all duration-500"
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Linked indicators */}
              <div className="grid grid-cols-2 gap-3 pt-5 mt-5 border-t border-zinc-800/40 text-xs">
                <div className="bg-zinc-900/40 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold text-zinc-500 uppercase block mb-1">Cible de projet</span>
                  <span className="text-zinc-300 font-mono font-bold">{fmt(goal.target)}</span>
                </div>
                <div className="bg-zinc-900/40 rounded-xl p-2.5">
                  <span className="text-[9px] font-bold text-zinc-500 uppercase block mb-1">Montant restant</span>
                  <span className="text-zinc-300 font-mono font-bold text-rose-400">
                    {fmt(Math.max(goal.target - currentProgressAmount, 0))}
                  </span>
                </div>
              </div>
            </div>
          )})}

        {savingGoals.length === 0 && (
          <div className="col-span-1 md:col-span-2 text-center py-12 bg-[#0e0e15] border border-dashed border-zinc-805 rounded-2xl flex flex-col items-center justify-center">
            <PiggyBank className="w-8 h-8 text-zinc-600 mb-3" />
            <p className="text-zinc-400 font-medium text-sm">Aucun objectif d'épargne planifié</p>
            {epargneAccounts.length === 0 ? (
              <p className="text-rose-400/80 text-xs mt-2 max-w-sm">
                ⚠️ Liaison Épargne obligatoire : Veuillez d'abord créer un compte bancaire de type "Épargne" pour pouvoir formuler un objectif d'épargne synchronisé.
              </p>
            ) : (
              <p className="text-zinc-600 text-xs mt-1">
                Définissez d'ambitieux objectifs budgétaires (vacances, voyages, sécurité d'épargne) et suivez votre balance.
              </p>
            )}
          </div>
        )}
      </div>

      {/* MODAL: ADD GOAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md transition-all">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative">
            <h3 className="text-base font-bold text-white mb-4">Créer un objectif d'épargne synchronisé</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Nom de l'objectif de placement
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Vacances d'Été, Apport Immobilier, Livret A Sécurité"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Montant de cible d'épargne (€)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="1000.00"
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white font-mono placeholder-zinc-700 focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                    Associer au compte d'Épargne réel
                  </label>
                  <select
                    value={linkedAccountId}
                    onChange={(e) => setLinkedAccountId(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                  >
                    {epargneAccounts.map((a) => (
                      <option key={a.id} value={a.id}>{a.name} (Dispo : {a.balance.toLocaleString("fr-FR")}€)</option>
                    ))}
                  </select>
                </div>
              </div>

              <p className="text-[10px] text-zinc-500 leading-relaxed italic bg-zinc-900/40 p-2.5 rounded-lg border border-zinc-850">
                💡 Liaison d'épargne obligatoire : Budget Pro 6 va directement observer la balance de ce compte pour tracer la barre de progression en temps réel.
              </p>

              <div className="flex items-center gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-400 text-zinc-950 text-xs font-bold py-2.5 rounded-xl hover:bg-emerald-300 cursor-pointer transition-all"
                >
                  Ajouter l'objectif
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-bold py-2.5 rounded-xl hover:text-white transition-all cursor-pointer"
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
