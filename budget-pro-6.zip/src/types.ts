export type AccountType = "Courant" | "Epargne" | "Sandbox" | "Autre";

export interface Account {
  id: string;
  name: string;
  balance: number;
  type: AccountType;
  emoji: string;
  isMirror?: boolean; // Indique si c'est un compte miroir 100% local d'un compte synchronisé
  originalId?: string; // ID du compte original dupliqué
}

export interface Transaction {
  id: string;
  accountId: string;
  type: "Revenu" | "Depense" | "Transfert" | "Epargne";
  amount: number;
  description: string;
  category: string;
  date: string; // YYYY-MM-DD
  savingsId?: string | null;
}

export interface Subscription {
  id: string;
  name: string;
  accountId: string;
  type: "Revenu" | "Depense";
  amount: number;
  frequency: "daily" | "weekly" | "monthly" | "monthly_day" | "yearly";
  dayOfMonth?: number | null;
  category: string;
  nextDate: string; // YYYY-MM-DD
}

export interface SavingGoal {
  id: string;
  name: string;
  target: number;
  current: number;
  linkedAccountId: string; // Obligatoire : associé à un compte Epargne réel existant
}

export interface CalendarNote {
  date: string; // YYYY-MM-DD
  note: string;
}

export type DashboardBlock = "overview" | "charts" | "accounts" | "transactions";

export interface UserPreferences {
  incognito: boolean;
  dashboardOrder: DashboardBlock[];
  calendarShowNotesDirectly: boolean;
  excelColumnNames: {
    category: string;
    total: string;
    percentage: string;
    [key: string]: string; // support dynamic months
  };
}
