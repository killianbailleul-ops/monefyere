import React, { useState, useEffect } from "react";
import Dashboard from "./components/Dashboard";
import Accounts from "./components/Accounts";
import Transactions from "./components/Transactions";
import CalendarComponent from "./components/Calendar";
import Excel from "./components/Excel";
import Subscriptions from "./components/Subscriptions";
import Savings from "./components/Savings";
import Advisor from "./components/Advisor";
import Notes from "./components/Notes";
import Settings from "./components/Settings";
import { Account, Transaction, Subscription, SavingGoal, CalendarNote, UserPreferences } from "./types";
import { 
  BarChart3, 
  Wallet, 
  Coins, 
  Calendar as CalIcon, 
  Grid, 
  RefreshCw, 
  PiggyBank, 
  Sparkles, 
  Key, 
  Settings as SettingsIcon,
  LogOut,
  Eye,
  EyeOff,
  UserCheck,
  CheckCircle,
  HelpCircle,
} from "lucide-react";

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // User Auth Profile
  const [sessionUser, setSessionUser] = useState<string | null>(null);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [loginUser, setLoginUser] = useState("");
  const [loginPass, setLoginPass] = useState("");
  const [regUser, setRegUser] = useState("");
  const [regPass, setRegPass] = useState("");

  // Sync mode indicator
  const [syncMode, setSyncMode] = useState<"Local" | "Synchro Mobile">("Local");

  // Client global preferences
  const [preferences, setPreferences] = useState<UserPreferences>({
    incognito: false,
    dashboardOrder: ["overview", "charts", "accounts", "transactions"],
    calendarShowNotesDirectly: true,
    excelColumnNames: {
      category: "Catégorie",
      total: "Total Cumulé",
      percentage: "Pourcentage",
    },
  });

  // Database lists
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [savingGoals, setSavingGoals] = useState<SavingGoal[]>([]);
  const [calendarNotes, setCalendarNotes] = useState<CalendarNote[]>([]);
  const [notes, setNotes] = useState<any[]>([]);

  // Default Categories dictionary
  const categories: { [key: string]: string[] } = {
    Revenu: ["Salaire", "Freelance", "Bonus", "Remboursement", "Autre"],
    Depense: ["Alimentation", "Transport", "Loisirs", "Maison", "Sante", "Cadeaux", "Abonnement", "Autre"],
    Epargne: ["Vacances", "Épargne Sécurité", "Projet Immo", "Crypto"],
    Transfert: ["Transfert Interne"],
  };
  const [customCategories, setCustomCategories] = useState(categories);

  // Load active user session on startup
  useEffect(() => {
    const cachedUser = localStorage.getItem("budgetpro6_session");
    if (cachedUser) {
      setSessionUser(cachedUser);
      loadUserData(cachedUser);
    }
  }, []);

  const loadUserData = (username: string) => {
    const key = `budgetpro6_data_${username}`;
    const raw = localStorage.getItem(key);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (parsed.accounts) setAccounts(parsed.accounts);
        if (parsed.transactions) setTransactions(parsed.transactions);
        if (parsed.subscriptions) setSubscriptions(parsed.subscriptions);
        if (parsed.savingGoals) setSavingGoals(parsed.savingGoals);
        if (parsed.calendarNotes) setCalendarNotes(parsed.calendarNotes);
        if (parsed.notes) setNotes(parsed.notes);
        if (parsed.preferences) setPreferences(parsed.preferences);
        if (parsed.customCategories) setCustomCategories(parsed.customCategories);
      } catch (err) {
        console.error("Error feeding database on load", err);
      }
    } else {
      // Seed initial dummy data for realistic representation if blank
      const defaultAccounts: Account[] = [
        { id: "acc1", name: "🏦 BANQUE POPULAIRE", balance: 2450.45, type: "Courant", emoji: "🏦" },
        { id: "acc2", name: "🐖 LIVRET EPAGNE A", balance: 5032.00, type: "Epargne", emoji: "🐖" },
      ];
      setAccounts(defaultAccounts);
      setTransactions([]);
      setSubscriptions([]);
      setSavingGoals([]);
      setCalendarNotes([]);
      setNotes([]);
      setPreferences({
        incognito: false,
        dashboardOrder: ["overview", "charts", "accounts", "transactions"],
        calendarShowNotesDirectly: true,
        excelColumnNames: {
          category: "Catégorie",
          total: "Total Cumulé",
          percentage: "Pourcentage",
        },
      });
      setCustomCategories(categories);
    }
  };

  const saveUserData = (username: string, updatedState: {
    accounts?: Account[];
    transactions?: Transaction[];
    subscriptions?: Subscription[];
    savingGoals?: SavingGoal[];
    calendarNotes?: CalendarNote[];
    notes?: any[];
    preferences?: UserPreferences;
    customCategories?: typeof categories;
  }) => {
    const key = `budgetpro6_data_${username}`;
    const base = {
      accounts: updatedState.accounts ?? accounts,
      transactions: updatedState.transactions ?? transactions,
      subscriptions: updatedState.subscriptions ?? subscriptions,
      savingGoals: updatedState.savingGoals ?? savingGoals,
      calendarNotes: updatedState.calendarNotes ?? calendarNotes,
      notes: updatedState.notes ?? notes,
      preferences: updatedState.preferences ?? preferences,
      customCategories: updatedState.customCategories ?? customCategories,
    };
    localStorage.setItem(key, JSON.stringify(base));
  };

  // Auth Operations
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUser.trim() || !loginPass.trim()) return;

    const usersRaw = localStorage.getItem("budgetpro6_users") || "{}";
    const users = JSON.parse(usersRaw);

    if (users[loginUser.trim().toLowerCase()] === loginPass) {
      const uname = loginUser.trim().toLowerCase();
      setSessionUser(uname);
      localStorage.setItem("budgetpro6_session", uname);
      loadUserData(uname);
      setLoginUser("");
      setLoginPass("");
    } else {
      alert("⚠️ Erreur : Identifiant ou mot de passe de session incorrect.");
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regUser.trim() || !regPass.trim()) return;

    const usersRaw = localStorage.getItem("budgetpro6_users") || "{}";
    const users = JSON.parse(usersRaw);

    const uname = regUser.trim().toLowerCase();
    if (users[uname]) {
      alert("⚠️ Identifiant déjà utilisé par un autre profil local.");
      return;
    }

    users[uname] = regPass;
    localStorage.setItem("budgetpro6_users", JSON.stringify(users));
    setSessionUser(uname);
    localStorage.setItem("budgetpro6_session", uname);
    loadUserData(uname);
    setRegUser("");
    setRegPass("");
  };

  const handleLogout = () => {
    if (sessionUser) {
      saveUserData(sessionUser, {});
    }
    setSessionUser(null);
    localStorage.removeItem("budgetpro6_session");
  };

  // Profile Password reset
  const handleResetPassword = (current: string, next: string): boolean => {
    if (!sessionUser) return false;
    const usersRaw = localStorage.getItem("budgetpro6_users") || "{}";
    const users = JSON.parse(usersRaw);

    if (users[sessionUser] === current) {
      users[sessionUser] = next;
      localStorage.setItem("budgetpro6_users", JSON.stringify(users));
      return true;
    }
    return false;
  };

  // CASCADE USER PURGER - RGPD Suppression définitive
  const handlePurgeAllUserData = () => {
    if (!sessionUser) return;

    // Purge key of user data
    const dataKey = `budgetpro6_data_${sessionUser}`;
    localStorage.removeItem(dataKey);

    // Purge user login credentials
    const usersRaw = localStorage.getItem("budgetpro6_users") || "{}";
    const users = JSON.parse(usersRaw);
    delete users[sessionUser];
    localStorage.setItem("budgetpro6_users", JSON.stringify(users));

    // Clear session and state variables
    localStorage.removeItem("budgetpro6_session");
    setSessionUser(null);
    setAccounts([]);
    setTransactions([]);
    setSubscriptions([]);
    setSavingGoals([]);
    setCalendarNotes([]);
    setNotes([]);

    alert("✅ RGPD : Votre compte ainsi que la totalité des données liées (transactions, abonnements, objectifs, épargne, notes d'agenda) ont été purgés avec succès en cascade.");
  };

  // Preferences toggling
  const handleUpdatePreferences = (updated: Partial<UserPreferences>) => {
    const nextPrefs = { ...preferences, ...updated };
    setPreferences(nextPrefs);
    if (sessionUser) {
      saveUserData(sessionUser, { preferences: nextPrefs });
    }
  };

  // Accounts Operations
  const handleAddAccount = (acc: Omit<Account, "id">) => {
    if (!sessionUser) return;
    const newAcc: Account = {
      ...acc,
      id: `acc_${Date.now()}`,
    };
    const nextAccounts = [...accounts, newAcc];
    setAccounts(nextAccounts);
    saveUserData(sessionUser, { accounts: nextAccounts });
  };

  const handleDeleteAccount = (id: string) => {
    if (!sessionUser) return;
    // RGPD check: Cascade remove associated transactions
    const nextAccounts = accounts.filter((a) => a.id !== id);
    const nextTransactions = transactions.filter((tx) => tx.accountId !== id);

    setAccounts(nextAccounts);
    setTransactions(nextTransactions);
    saveUserData(sessionUser, { accounts: nextAccounts, transactions: nextTransactions });
  };

  // Solde "Anti-bug" - Direct balanced recalibration without adding toxic transactions
  const handleUpdateAccountBalance = (id: string, newBalance: number) => {
    if (!sessionUser) return;
    const nextAccounts = accounts.map((a) => (a.id === id ? { ...a, balance: newBalance } : a));
    setAccounts(nextAccounts);
    saveUserData(sessionUser, { accounts: nextAccounts });
  };

  // Duplicate active account into local mirror (Sandbox)
  const handleDuplicateLocalMirror = (id: string) => {
    if (!sessionUser) return;
    const orig = accounts.find((a) => a.id === id);
    if (!orig) return;

    const dup: Account = {
      id: `acc_${Date.now()}`,
      name: `${orig.name} LO-SANDBOX`,
      balance: orig.balance,
      type: "Sandbox",
      emoji: "🧪",
      isMirror: true,
      originalId: orig.id,
    };

    const nextAccounts = [...accounts, dup];
    setAccounts(nextAccounts);
    saveUserData(sessionUser, { accounts: nextAccounts });
    alert(`🧪 Sandbox : Le compte "${orig.name}" a été dupliqué en miroir d'essai 100% local.`);
  };

  // Transactions Operations
  const handleAddTransaction = (tx: Omit<Transaction, "id">) => {
    if (!sessionUser) return;
    const newTx: Transaction = {
      ...tx,
      id: `tx_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    };

    // Recalibrate appropriate balances in cascade
    let nextAccounts = [...accounts];
    if (tx.type === "Revenu") {
      nextAccounts = nextAccounts.map((a) => (a.id === tx.accountId ? { ...a, balance: a.balance + tx.amount } : a));
    } else if (tx.type === "Depense" || tx.type === "Epargne") {
      nextAccounts = nextAccounts.map((a) => (a.id === tx.accountId ? { ...a, balance: a.balance - tx.amount } : a));
    }

    // Sync contribution to linked savings target progress
    let nextSavingGoals = [...savingGoals];
    if (tx.type === "Epargne" && tx.savingsId) {
      nextSavingGoals = nextSavingGoals.map((g) =>
        g.id === tx.savingsId ? { ...g, current: g.current + tx.amount } : g
      );
    }

    const nextTransactions = [...transactions, newTx];
    setTransactions(nextTransactions);
    setAccounts(nextAccounts);
    setSavingGoals(nextSavingGoals);
    saveUserData(sessionUser, {
      transactions: nextTransactions,
      accounts: nextAccounts,
      savingGoals: nextSavingGoals,
    });
  };

  const handleUpdateTransaction = (id: string, updated: Partial<Transaction>) => {
    if (!sessionUser) return;

    const origTx = transactions.find((t) => t.id === id);
    if (!origTx) return;

    let nextAccounts = [...accounts];

    // Revert old transaction amounts
    if (origTx.type === "Revenu") {
      nextAccounts = nextAccounts.map((a) => (a.id === origTx.accountId ? { ...a, balance: a.balance - origTx.amount } : a));
    } else if (origTx.type === "Depense" || origTx.type === "Epargne") {
      nextAccounts = nextAccounts.map((a) => (a.id === origTx.accountId ? { ...a, balance: a.balance + origTx.amount } : a));
    }

    // Process new amounts
    const updatedTx = { ...origTx, ...updated };
    if (updatedTx.type === "Revenu") {
      nextAccounts = nextAccounts.map((a) => (a.id === updatedTx.accountId ? { ...a, balance: a.balance + updatedTx.amount } : a));
    } else if (updatedTx.type === "Depense" || updatedTx.type === "Epargne") {
      nextAccounts = nextAccounts.map((a) => (a.id === updatedTx.accountId ? { ...a, balance: a.balance - updatedTx.amount } : a));
    }

    const nextTransactions = transactions.map((t) => (t.id === id ? updatedTx : t));
    setTransactions(nextTransactions);
    setAccounts(nextAccounts);
    saveUserData(sessionUser, {
      transactions: nextTransactions,
      accounts: nextAccounts,
    });
  };

  const handleDeleteTransaction = (id: string) => {
    if (!sessionUser) return;
    const tx = transactions.find((t) => t.id === id);
    if (!tx) return;

    let nextAccounts = [...accounts];
    // Revert balance alterations
    if (tx.type === "Revenu") {
      nextAccounts = nextAccounts.map((a) => (a.id === tx.accountId ? { ...a, balance: a.balance - tx.amount } : a));
    } else if (tx.type === "Depense" || tx.type === "Epargne") {
      nextAccounts = nextAccounts.map((a) => (a.id === tx.accountId ? { ...a, balance: a.balance + tx.amount } : a));
    }

    const nextTransactions = transactions.filter((t) => t.id !== id);
    setTransactions(nextTransactions);
    setAccounts(nextAccounts);
    saveUserData(sessionUser, { transactions: nextTransactions, accounts: nextAccounts });
  };

  // Subscriptions Operations
  const handleAddSubscription = (sub: Omit<Subscription, "id">) => {
    if (!sessionUser) return;
    const newSub: Subscription = {
      ...sub,
      id: `sub_${Date.now()}`,
    };
    const nextSubs = [...subscriptions, newSub];
    setSubscriptions(nextSubs);
    saveUserData(sessionUser, { subscriptions: nextSubs });
  };

  const handleDeleteSubscription = (id: string) => {
    if (!sessionUser) return;
    const nextSubs = subscriptions.filter((s) => s.id !== id);
    setSubscriptions(nextSubs);
    saveUserData(sessionUser, { subscriptions: nextSubs });
  };

  // Saving Goals Operations
  const handleAddSavingGoal = (goal: Omit<SavingGoal, "id">) => {
    if (!sessionUser) return;
    const newGoal: SavingGoal = {
      ...goal,
      id: `goal_${Date.now()}`,
    };
    const nextGoals = [...savingGoals, newGoal];
    setSavingGoals(nextGoals);
    saveUserData(sessionUser, { savingGoals: nextGoals });
  };

  const handleDeleteSavingGoal = (id: string) => {
    if (!sessionUser) return;
    const nextGoals = savingGoals.filter((g) => g.id !== id);
    setSavingGoals(nextGoals);
    saveUserData(sessionUser, { savingGoals: nextGoals });
  };

  // Calendar Notes Operations
  const handleSaveCalendarNote = (date: string, noteText: string) => {
    if (!sessionUser) return;
    let nextNotes = [...calendarNotes];
    if (noteText === "") {
      nextNotes = nextNotes.filter((n) => n.date !== date);
    } else {
      const idx = nextNotes.findIndex((n) => n.date === date);
      if (idx !== -1) {
        nextNotes[idx].note = noteText;
      } else {
        nextNotes.push({ date, note: noteText });
      }
    }
    setCalendarNotes(nextNotes);
    saveUserData(sessionUser, { calendarNotes: nextNotes });
  };

  // Credentials Notes (Coffre-fort)
  const handleAddNote = (note: any) => {
    if (!sessionUser) return;
    const newNote = {
      ...note,
      id: `note_${Date.now()}`,
      updated: new Date().toISOString().split("T")[0],
    };
    const nextNotes = [...notes, newNote];
    setNotes(nextNotes);
    saveUserData(sessionUser, { notes: nextNotes });
  };

  const handleDeleteNote = (id: string) => {
    if (!sessionUser) return;
    const nextNotes = notes.filter((n) => n.id !== id);
    setNotes(nextNotes);
    saveUserData(sessionUser, { notes: nextNotes });
  };

  // Custom Category additions
  const handleAddCategory = (type: string, catName: string) => {
    if (!sessionUser) return;
    const nextCats = { ...customCategories };
    if (!nextCats[type]) nextCats[type] = [];
    if (!nextCats[type].includes(catName)) {
      nextCats[type].push(catName);
    }
    setCustomCategories(nextCats);
    saveUserData(sessionUser, { customCategories: nextCats });
  };

  const handleDeleteCategory = (type: string, catName: string) => {
    if (!sessionUser) return;
    const nextCats = { ...customCategories };
    if (nextCats[type]) {
      nextCats[type] = nextCats[type].filter((c) => c !== catName);
    }
    setCustomCategories(nextCats);
    saveUserData(sessionUser, { customCategories: nextCats });
  };

  // AUTH STATE RENDERING
  if (!sessionUser) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#07070a] text-zinc-100 p-4">
        {/* Abstract vector backgrounds */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(16,185,129,0.06),transparent_50%)] pointer-events-none" />

        <div className="relative bg-zinc-950 border border-zinc-850/80 w-full max-w-md rounded-2xl p-8 shadow-2xl space-y-6">
          <div className="text-center">
            <h1 className="text-2xl font-extrabold tracking-tight text-white flex items-center justify-center gap-2">
              💰 Budget <span className="text-emerald-400 font-medium">Pro 6</span>
            </h1>
            <p className="text-zinc-500 text-xs mt-2">
              Le pilotage financier d'élite modulaire autonome &amp; IA de confiance
            </p>
          </div>

          {authMode === "login" ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Identifiant local
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: samy"
                  value={loginUser}
                  onChange={(e) => setLoginUser(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400 font-medium"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Mot de passe de session
                </label>
                <input
                  type="password"
                  required
                  placeholder="••••••••••••"
                  value={loginPass}
                  onChange={(e) => setLoginPass(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400 font-medium"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-400 text-zinc-950 font-bold py-3 rounded-xl text-xs hover:bg-emerald-300 cursor-pointer transition-all shadow-lg"
              >
                Se connecter à l'espace
              </button>

              <p className="text-center text-xs text-zinc-500 pt-2">
                Nouveau profil ?{" "}
                <button
                  type="button"
                  onClick={() => setAuthMode("register")}
                  className="text-emerald-400 font-bold hover:underline cursor-pointer"
                >
                  Initier un profil local
                </button>
              </p>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Identifiant de profil
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: samy"
                  value={regUser}
                  onChange={(e) => setRegUser(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400 font-medium"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
                  Mot de passe d'accès sécurisé
                </label>
                <input
                  type="password"
                  required
                  placeholder="••••••••••••"
                  value={regPass}
                  onChange={(e) => setRegPass(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-400 font-medium"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-400 text-zinc-950 font-bold py-3 rounded-xl text-xs hover:bg-emerald-300 cursor-pointer transition-all shadow-lg"
              >
                Créer l'espace local
              </button>

              <p className="text-center text-xs text-zinc-500 pt-2">
                Déjà inscrit ?{" "}
                <button
                  type="button"
                  onClick={() => setAuthMode("login")}
                  className="text-emerald-400 font-bold hover:underline cursor-pointer"
                >
                  S'identifier
                </button>
              </p>
            </form>
          )}

          {/* Secure credentials disclaimer */}
          <div className="bg-zinc-900/40 border border-zinc-850 p-3.5 rounded-xl text-[10px] text-zinc-500 leading-relaxed text-center">
            🔒 <strong>Isolât local :</strong> Budget Pro 6 est autonome. Vos bases de données budgétaires et identifiants restent stockés localement sur votre appareil pour respecter la loi RGPD.
          </div>
        </div>
      </div>
    );
  }

  // APP WORKSPACE RENDERING
  return (
    <div className="min-h-screen bg-[#07070a] text-zinc-100 flex flex-col md:flex-row antialiased">
      {/* SIDEBAR NAVIGATION PANEL */}
      <aside className="w-full md:w-64 bg-zinc-950 border-b md:border-b-0 md:border-r border-zinc-900/60 flex flex-col p-5 shrink-0 z-10">
        <div className="mb-8 flex items-center justify-between">
          <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
            💰 Budget <span className="text-emerald-400 font-medium">Pro 6</span>
          </h1>
          <span className="text-[9px] font-bold bg-emerald-400/10 text-emerald-400 rounded-md px-2 py-0.5 border border-emerald-400/10 tracking-widest leading-none">
            V6.1
          </span>
        </div>

        {/* Navigation Elements */}
        <nav className="flex-1 space-y-1.5">
          <span className="block text-[9px] font-bold text-zinc-650 uppercase tracking-widest mb-3 pl-3">
            Principal
          </span>

          <button
            onClick={() => setActiveTab("dashboard")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "dashboard"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <BarChart3 className="w-4 h-4" /> Tableau de Bord
          </button>

          <button
            onClick={() => setActiveTab("accounts")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "accounts"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <Wallet className="w-4 h-4" /> Comptes Bancaires
          </button>

          <button
            onClick={() => setActiveTab("transactions")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "transactions"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <Coins className="w-4 h-4" /> Transactions
          </button>

          <span className="block text-[9px] font-bold text-zinc-655 uppercase tracking-widest pt-5 mb-3 pl-3">
            Outils &amp; Ledger
          </span>

          <button
            onClick={() => setActiveTab("calendar")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "calendar"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <CalIcon className="w-4 h-4" /> Agenda Budgétaire
          </button>

          <button
            onClick={() => setActiveTab("excel")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "excel"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <Grid className="w-4 h-4" /> Tableau mensuel
          </button>

          <button
            onClick={() => setActiveTab("subscriptions")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "subscriptions"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <RefreshCw className="w-4 h-4" /> Abonnements
          </button>

          <button
            onClick={() => setActiveTab("savings")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "savings"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <PiggyBank className="w-4 h-4" /> Epargne &amp; Projets
          </button>

          <span className="block text-[9px] font-bold text-zinc-655 uppercase tracking-widest pt-5 mb-3 pl-3">
            Sécurité &amp; IA
          </span>

          <button
            onClick={() => setActiveTab("advisor")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "advisor"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <Sparkles className="w-4 h-4" /> Conseiller IA
          </button>

          <button
            onClick={() => setActiveTab("notes")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "notes"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <Key className="w-4 h-4" /> Coffre Mots de passe
          </button>

          <button
            onClick={() => setActiveTab("settings")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              activeTab === "settings"
                ? "bg-emerald-400/10 text-emerald-400 font-bold border border-emerald-400/10 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40 border border-transparent"
            }`}
          >
            <SettingsIcon className="w-4 h-4" /> Paramètres
          </button>
        </nav>

        {/* Sidebar Footer space */}
        <div className="pt-6 border-t border-zinc-900 mt-6 space-y-4">
          <div className="flex items-center gap-2.5 bg-zinc-900/40 border border-zinc-850 p-3 rounded-2xl">
            <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-xs uppercase shrink-0">
              {sessionUser?.slice(0, 2)}
            </div>
            <div className="min-w-0">
              <span className="text-[11px] font-bold text-white block truncate uppercase">{sessionUser}</span>
              <span className="text-[9px] text-zinc-500 mt-0.5 block leading-none">Profil actif</span>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="w-full bg-rose-500/10 hover:bg-rose-500 text-rose-450 hover:text-white rounded-xl py-2 px-3 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <LogOut className="w-4 h-4" /> Quitter la session
          </button>
        </div>
      </aside>

      {/* CORE WORKSPACE SCREEN */}
      <main className="flex-1 flex flex-col min-w-0 z-0 select-text overflow-x-hidden">
        {/* TOPBAR HEADER PANEL */}
        <header className="bg-zinc-950/75 backdrop-blur-md border-b border-zinc-900/60 h-16 flex items-center justify-between px-6 shrink-0 relative z-20">
          <div className="flex items-center gap-2 font-bold text-zinc-400 text-xs">
            <span>Budget Pro 6</span>
            <span>/</span>
            <span className="text-white capitalize font-semibold">{activeTab}</span>
          </div>

          <div className="flex items-center gap-4">
            {/* Sync Mode Switch */}
            <div className="flex items-center gap-2 bg-zinc-900/80 border border-zinc-850 rounded-full px-3 py-1 text-[11px] font-mono select-none">
              <span
                onClick={() => setSyncMode(syncMode === "Local" ? "Synchro Mobile" : "Local")}
                className="cursor-pointer hover:opacity-80 flex items-center gap-1"
                title="Cliquez pour permuter le type de synchro"
              >
                <div className={`w-1.5 h-1.5 rounded-full ${syncMode === "Local" ? "bg-amber-400 animate-pulse" : "bg-emerald-400"}`} />
                <span className="text-zinc-500">&lt;</span>
                <span className={syncMode === "Local" ? "text-amber-400 font-semibold" : "text-emerald-400 font-semibold"}>
                  {syncMode === "Local" ? "Local" : "Synchro Mobile"}
                </span>
                <span className="text-zinc-500">&gt;</span>
              </span>
            </div>

            {/* Incognito eyebutton */}
            <button
              onClick={() => handleUpdatePreferences({ incognito: !preferences.incognito })}
              className={`p-2 rounded-xl transition-all border cursor-pointer hover:bg-zinc-900 ${
                preferences.incognito
                  ? "bg-amber-400/15 border-amber-400/20 text-amber-500"
                  : "bg-zinc-950/80 border-zinc-900 text-zinc-400 hover:text-white"
              }`}
              title={preferences.incognito ? "Désactiver le mode masquage (Incognito)" : "Activer le mode masquage publique (Incognito)"}
            >
              {preferences.incognito ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {/* CONTAINER CONTENT AREA */}
        <div className="flex-1 p-6 sm:p-8 overflow-y-auto max-w-7xl w-full mx-auto space-y-6">
          {activeTab === "dashboard" && (
            <Dashboard
              accounts={accounts}
              transactions={transactions}
              preferences={preferences}
              onUpdatePreferences={handleUpdatePreferences}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === "accounts" && (
            <Accounts
              accounts={accounts}
              onAddAccount={handleAddAccount}
              onDeleteAccount={handleDeleteAccount}
              onUpdateAccountBalance={handleUpdateAccountBalance}
              onDuplicateLocalMirror={handleDuplicateLocalMirror}
              incognito={preferences.incognito}
            />
          )}

          {activeTab === "transactions" && (
            <Transactions
              accounts={accounts}
              transactions={transactions}
              savingGoals={savingGoals}
              onAddTransaction={handleAddTransaction}
              onDeleteTransaction={handleDeleteTransaction}
              categories={customCategories}
              incognito={preferences.incognito}
            />
          )}

          {activeTab === "calendar" && (
            <CalendarComponent
              accounts={accounts}
              transactions={transactions}
              preferences={preferences}
              onUpdatePreferences={handleUpdatePreferences}
              calendarNotes={calendarNotes}
              onSaveCalendarNote={handleSaveCalendarNote}
              incognito={preferences.incognito}
            />
          )}

          {activeTab === "excel" && (
            <Excel
              accounts={accounts}
              transactions={transactions}
              preferences={preferences}
              onUpdatePreferences={handleUpdatePreferences}
              onUpdateTransaction={handleUpdateTransaction}
              incognito={preferences.incognito}
            />
          )}

          {activeTab === "subscriptions" && (
            <Subscriptions
              accounts={accounts}
              subscriptions={subscriptions}
              onAddSubscription={handleAddSubscription}
              onDeleteSubscription={handleDeleteSubscription}
              categories={customCategories}
              incognito={preferences.incognito}
            />
          )}

          {activeTab === "savings" && (
            <Savings
              accounts={accounts}
              savingGoals={savingGoals}
              onAddSavingGoal={handleAddSavingGoal}
              onDeleteSavingGoal={handleDeleteSavingGoal}
              incognito={preferences.incognito}
            />
          )}

          {activeTab === "advisor" && (
            <Advisor
              accounts={accounts}
              transactions={transactions}
              subscriptions={subscriptions}
              savingGoals={savingGoals}
            />
          )}

          {activeTab === "notes" && (
            <Notes
              notes={notes}
              onAddNote={handleAddNote}
              onDeleteNote={handleDeleteNote}
            />
          )}

          {activeTab === "settings" && (
            <Settings
              categories={customCategories}
              onAddCategory={handleAddCategory}
              onDeleteCategory={handleDeleteCategory}
              onResetPassword={handleResetPassword}
              onPurgeAllUserData={handlePurgeAllUserData}
            />
          )}
        </div>
      </main>
    </div>
  );
}
