import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Budget Advisor (server-side Gemini)
  app.post("/api/advisor", async (req: express.Request, res: express.Response) => {
    try {
      const { message, context } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(400).json({ 
          error: "Clé API Gemini non configurée sur le serveur. Veuillez configurer la variable GEMINI_API_KEY dans le panneau des secrets d'AI Studio." 
        });
      }

      const ai = new GoogleGenAI({ apiKey });
      const prompt = `
Tu es l'assistant financier virtuel d'élite et de confiance nommé "Budget Pro 6 AI Advisor". Ton objectif est d'analyser le budget de l'utilisateur, ses transactions, et de lui procurer des conseils clairs, actionnables et motivants.

Voici la situation financière globale de l'utilisateur :
${context}

L'utilisateur te demande : "${message}"

Consignes pour ton analyse :
1. Réponds en français de manière élégante, professionnelle et optimiste.
2. Utilise des émojis pertinents, des listes à puces claires et des termes budgétaires précis (ex: cash-flow, taux d'épargne, arbitrage budgétaire).
3. Ne te contente pas de généralités. Donne des pourcentages, des ratios ou des calculs de simulation budgétaire si possible (ex: règle des 50/30/20, réduction d'abonnements, intérêts cumulés).
4. S'il te demande d'analyser ses dépenses ou de l'aider à atteindre un objectif d'épargne, fais une simulation mathématique simple et encourageante.
5. Garde un ton objectif mais motivant. N'incite pas à l'investissement spéculatif risqué, propose plutôt du bon sens bancaire et des arbitrages de dépenses superflues.
`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      res.json({ reply: response.text });
    } catch (error: any) {
      console.error("Gemini Advisor API Error:", error);
      res.status(500).json({ error: error.message || "Une erreur interne est survenue lors de l'appel à l'intelligence artificielle." });
    }
  });

  // Vite development middleware vs Static Production files serving
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req: express.Request, res: express.Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Budget Pro 6 Server] En ligne sur http://localhost:${PORT}`);
  });
}

startServer();
